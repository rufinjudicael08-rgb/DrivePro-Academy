/*
# DrivePro Academy — Core Schema

1. New Tables
- `registrations` — candidate enrollment records with tunnel status tracking.
  - `id` uuid PK
  - `full_name` text NOT NULL
  - `email` text NOT NULL
  - `phone` text NOT NULL
  - `country_code` text NOT NULL (ISO 3166-1 alpha-2)
  - `city` text NOT NULL
  - `birth_date` date
  - `locale` text NOT NULL DEFAULT 'fr' (fr or en)
  - `currency` text NOT NULL DEFAULT 'EUR'
  - `payment_method` text (card, mobile_money, paypal, sepa, bank_transfer)
  - `payment_status` text NOT NULL DEFAULT 'pending' (pending, paid)
  - `file_complete` boolean NOT NULL DEFAULT false
  - `admin_fee_base` integer NOT NULL DEFAULT 25000 (in base EUR/FCFA units)
  - `queue_number` integer
  - `queue_position` integer
  - `queue_status` text NOT NULL DEFAULT 'pending' (pending, waiting, in_course, validated)
  - `code_exam_score` integer DEFAULT 0
  - `code_exam_passed` boolean NOT NULL DEFAULT false
  - `instructor_id` uuid
  - `created_at` timestamptz DEFAULT now()
  - `updated_at` timestamptz DEFAULT now()

- `instructors` — certified driving instructors for practical lessons.
  - `id` uuid PK
  - `name` text NOT NULL
  - `phone` text NOT NULL
  - `whatsapp` text NOT NULL
  - `city` text NOT NULL
  - `country_code` text NOT NULL
  - `rating` numeric DEFAULT 5.0
  - `languages` text[] DEFAULT '{}'

- `code_courses` — online theory lessons.
  - `id` uuid PK
  - `title_fr` text NOT NULL
  - `title_en` text NOT NULL
  - `description_fr` text NOT NULL
  - `description_en` text NOT NULL
  - `duration_minutes` integer NOT NULL DEFAULT 30
  - `lesson_order` integer NOT NULL DEFAULT 0
  - `is_exam` boolean NOT NULL DEFAULT false

- `social_campaigns` — tracked social media acquisition campaigns.
  - `id` uuid PK
  - `platform` text NOT NULL (tiktok, facebook, instagram)
  - `label` text NOT NULL
  - `tracked_url` text NOT NULL
  - `clicks` integer NOT NULL DEFAULT 0
  - `conversions` integer NOT NULL DEFAULT 0
  - `active` boolean NOT NULL DEFAULT true
  - `created_at` timestamptz DEFAULT now()

2. Security
- Enable RLS on all tables.
- This is a public-facing app (no sign-in for candidates), so:
  - `registrations`: anon+authenticated can INSERT and SELECT their own by email; UPDATE for status changes.
  - `instructors`: anon+authenticated can SELECT.
  - `code_courses`: anon+authenticated can SELECT.
  - `social_campaigns`: anon+authenticated can SELECT; UPDATE for click tracking.
- service_role granted for edge function access.

3. Important Notes
- Queue numbers are assigned sequentially via a counter pattern.
- The registration tunnel is enforced at the application layer: file_complete + payment_status='paid' unlock queue; queue_status='validated' + code_exam_passed unlock instructor contact.
- Base admin fee is 25000, converted client-side based on selected country currency.
*/

-- === registrations ===
CREATE TABLE IF NOT EXISTS registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  country_code text NOT NULL,
  city text NOT NULL,
  birth_date date,
  locale text NOT NULL DEFAULT 'fr',
  currency text NOT NULL DEFAULT 'EUR',
  payment_method text,
  payment_status text NOT NULL DEFAULT 'pending',
  file_complete boolean NOT NULL DEFAULT false,
  admin_fee_base integer NOT NULL DEFAULT 25000,
  queue_number integer,
  queue_position integer,
  queue_status text NOT NULL DEFAULT 'pending',
  code_exam_score integer DEFAULT 0,
  code_exam_passed boolean NOT NULL DEFAULT false,
  instructor_id uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE registrations ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON registrations TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON registrations TO service_role;

DROP POLICY IF EXISTS "anon_select_registrations" ON registrations;
CREATE POLICY "anon_select_registrations" ON registrations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_registrations" ON registrations;
CREATE POLICY "anon_insert_registrations" ON registrations FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_registrations" ON registrations;
CREATE POLICY "anon_update_registrations" ON registrations FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_registrations" ON registrations;
CREATE POLICY "anon_delete_registrations" ON registrations FOR DELETE
  TO anon, authenticated USING (true);

-- === instructors ===
CREATE TABLE IF NOT EXISTS instructors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  whatsapp text NOT NULL,
  city text NOT NULL,
  country_code text NOT NULL,
  rating numeric DEFAULT 5.0,
  languages text[] DEFAULT '{}'
);

ALTER TABLE instructors ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON instructors TO anon, authenticated;
GRANT SELECT ON instructors TO service_role;

DROP POLICY IF EXISTS "anon_select_instructors" ON instructors;
CREATE POLICY "anon_select_instructors" ON instructors FOR SELECT
  TO anon, authenticated USING (true);

-- === code_courses ===
CREATE TABLE IF NOT EXISTS code_courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title_fr text NOT NULL,
  title_en text NOT NULL,
  description_fr text NOT NULL,
  description_en text NOT NULL,
  duration_minutes integer NOT NULL DEFAULT 30,
  lesson_order integer NOT NULL DEFAULT 0,
  is_exam boolean NOT NULL DEFAULT false
);

ALTER TABLE code_courses ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON code_courses TO anon, authenticated;
GRANT SELECT ON code_courses TO service_role;

DROP POLICY IF EXISTS "anon_select_code_courses" ON code_courses;
CREATE POLICY "anon_select_code_courses" ON code_courses FOR SELECT
  TO anon, authenticated USING (true);

-- === social_campaigns ===
CREATE TABLE IF NOT EXISTS social_campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  platform text NOT NULL,
  label text NOT NULL,
  tracked_url text NOT NULL,
  clicks integer NOT NULL DEFAULT 0,
  conversions integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE social_campaigns ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON social_campaigns TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON social_campaigns TO service_role;

DROP POLICY IF EXISTS "anon_select_social_campaigns" ON social_campaigns;
CREATE POLICY "anon_select_social_campaigns" ON social_campaigns FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_social_campaigns" ON social_campaigns;
CREATE POLICY "anon_insert_social_campaigns" ON social_campaigns FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_social_campaigns" ON social_campaigns;
CREATE POLICY "anon_update_social_campaigns" ON social_campaigns FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

-- === Indexes ===
CREATE INDEX IF NOT EXISTS idx_registrations_email ON registrations(email);
CREATE INDEX IF NOT EXISTS idx_registrations_country ON registrations(country_code);
CREATE INDEX IF NOT EXISTS idx_registrations_status ON registrations(payment_status);
CREATE INDEX IF NOT EXISTS idx_instructors_country ON instructors(country_code);
CREATE INDEX IF NOT EXISTS idx_code_courses_order ON code_courses(lesson_order);
CREATE INDEX IF NOT EXISTS idx_social_campaigns_platform ON social_campaigns(platform);

-- === Seed: code courses ===
INSERT INTO code_courses (title_fr, title_en, description_fr, description_en, duration_minutes, lesson_order, is_exam) VALUES
('Les panneaux de signalisation', 'Traffic Signs', 'Apprenez tous les panneaux de signalisation routière.', 'Learn all road traffic signs and their meanings.', 45, 1, false),
('Priorités et croisements', 'Right-of-Way & Intersections', 'Maîtrisez les règles de priorité aux carrefours.', 'Master right-of-way rules at intersections.', 40, 2, false),
('Vitesse et distances de sécurité', 'Speed & Safety Distances', 'Comprenez les limitations de vitesse et distances.', 'Understand speed limits and safe following distances.', 35, 3, false),
('L''alcool et la conduite', 'Alcohol & Driving', 'Les effets de l''alcool sur la conduite et la loi.', 'Effects of alcohol on driving and legal limits.', 30, 4, false),
('Conduite en conditions difficiles', 'Driving in Difficult Conditions', 'Pluie, neige, brouillard : conduite sécuritaire.', 'Rain, snow, fog: safe driving techniques.', 40, 5, false),
('Examen blanc — Code de la route', 'Mock Exam — Highway Code', 'Examen final blanc de 40 questions.', 'Final mock exam with 40 questions.', 60, 6, true)
ON CONFLICT DO NOTHING;

-- === Seed: instructors ===
INSERT INTO instructors (name, phone, whatsapp, city, country_code, rating, languages) VALUES
('Jean-Marc Dubois', '+33 6 12 34 56 78', '+33612345678', 'Paris', 'FR', 4.9, ARRAY['fr','en']),
('Sofia Petrova', '+359 88 123 4567', '+359881234567', 'Sofia', 'BG', 4.8, ARRAY['bg','en']),
('Anna Kowalska', '+48 600 123 456', '+48600123456', 'Warsaw', 'PL', 4.7, ARRAY['pl','en']),
('Carlos Fernández', '+34 612 34 56 78', '+34612345678', 'Madrid', 'ES', 4.9, ARRAY['es','en']),
('Lars Nielsen', '+45 20 12 34 56', '+4520123456', 'Copenhagen', 'DK', 5.0, ARRAY['da','en']),
('Koffi Adjovi', '+229 90 12 34 56', '+22990123456', 'Cotonou', 'BJ', 4.8, ARRAY['fr'])
ON CONFLICT DO NOTHING;

-- === Seed: social campaigns ===
INSERT INTO social_campaigns (platform, label, tracked_url, clicks, conversions, active) VALUES
('tiktok', 'TikTok — Astuces Code', 'https://tiktok.com/@driveproacademy', 342, 28, true),
('facebook', 'Facebook — Inscriptions Ouvertes', 'https://facebook.com/driveproacademy', 218, 19, true),
('instagram', 'Instagram — Témoignages', 'https://instagram.com/driveproacademy', 156, 12, true)
ON CONFLICT DO NOTHING;