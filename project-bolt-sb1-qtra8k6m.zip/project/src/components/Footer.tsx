import { Car, MapPin, Mail, Phone, Shield } from 'lucide-react';
import { useApp } from '@/lib/context';
import type { View } from '@/lib/types';

export default function Footer({ onNavigate }: { onNavigate: (view: View) => void }) {
  const { t, locale } = useApp();

  return (
    <footer className="bg-slate-900 text-white/70 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                <Car className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-white font-bold text-lg leading-tight">DrivePro Academy</div>
                <div className="text-blue-300 text-[10px] tracking-wider uppercase">{t('footerLicense')}</div>
              </div>
            </div>
            <p className="text-sm max-w-md leading-relaxed">{t('footerAboutDesc')}</p>
            <div className="flex items-center gap-2 mt-4 text-sm">
              <MapPin className="w-4 h-4 text-blue-400" />
              <span>{t('footerAddress')}</span>
            </div>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">{t('footerLinks')}</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => onNavigate('home')} className="hover:text-blue-400 transition-colors">{t('home')}</button></li>
              <li><button onClick={() => onNavigate('register')} className="hover:text-blue-400 transition-colors">{t('register')}</button></li>
              <li><button onClick={() => onNavigate('candidate')} className="hover:text-blue-400 transition-colors">{t('candidateSpace')}</button></li>
              <li><button onClick={() => onNavigate('agent')} className="hover:text-blue-400 transition-colors">{t('agentSpace')}</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold mb-4 text-sm">{t('footerContact')}</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-blue-400" />
                <span>+33 1 42 00 00 00</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-blue-400" />
                <span>contact@drivepro.academy</span>
              </li>
              <li className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-400" />
                <span>{locale === 'fr' ? 'Agréé par l\'État' : 'State-accredited'}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 text-center text-xs text-white/50">
          © {new Date().getFullYear()} DrivePro Academy. {t('footerRights')}
        </div>
      </div>
    </footer>
  );
}
