import { useState, useEffect, useCallback } from 'react';
import {
  Share2, Users, TrendingUp, Link2, Copy, Check, BarChart3,
  Music, Facebook, Instagram, ExternalLink, Loader2, CreditCard,
  Clock, CheckCircle2, AlertCircle, Download, FileSpreadsheet, FileText
} from 'lucide-react';
import { useApp } from '@/lib/context';
import { supabase } from '@/lib/supabase';
import { getCountry } from '@/lib/countries';
import { registrationsToCSV, registrationsToExcelXML, downloadFile } from '@/lib/exportUtils';
import type { SocialCampaign, Registration, View } from '@/lib/types';

export default function AgentSpace({ onNavigate }: { onNavigate: (view: View) => void }) {
  const { t, locale } = useApp();
  const [campaigns, setCampaigns] = useState<SocialCampaign[]>([]);
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [stats, setStats] = useState({ total: 0, paid: 0, pending: 0, validated: 0 });
  const [exporting, setExporting] = useState(false);
  const [exportMsg, setExportMsg] = useState('');

  const loadData = useCallback(async () => {
    const [campRes, regRes] = await Promise.all([
      supabase.from('social_campaigns').select('*').order('created_at'),
      supabase.from('registrations').select('*').order('created_at', { ascending: false }).limit(50),
    ]);

    setCampaigns(campRes.data || []);
    setRegistrations(regRes.data || []);

    const regs = regRes.data || [];
    setStats({
      total: regs.length,
      paid: regs.filter((r) => r.payment_status === 'paid').length,
      pending: regs.filter((r) => r.payment_status === 'pending').length,
      validated: regs.filter((r) => r.queue_status === 'validated').length,
    });

    setLoading(false);
  }, []);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, [loadData]);

  const copyLink = async (campaign: SocialCampaign) => {
    try {
      await navigator.clipboard.writeText(campaign.tracked_url);
      setCopiedId(campaign.id);
      // Track click
      await supabase
        .from('social_campaigns')
        .update({ clicks: campaign.clicks + 1 })
        .eq('id', campaign.id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      // Fallback
    }
  };

  const platformIcons: Record<string, typeof Music> = {
    tiktok: Music,
    facebook: Facebook,
    instagram: Instagram,
  };

  const platformColors: Record<string, string> = {
    tiktok: 'from-gray-800 to-gray-900',
    facebook: 'from-blue-600 to-blue-700',
    instagram: 'from-purple-500 via-pink-500 to-orange-400',
  };

  const statusLabel = (status: string) => {
    const map: Record<string, string> = {
      pending: t('statusPending'),
      paid: t('statusPaid'),
      waiting: t('statusWaiting'),
      in_course: t('statusInCourse'),
      validated: t('statusValidated'),
    };
    return map[status] || status;
  };

  const statusColor = (status: string) => {
    if (status === 'paid' || status === 'validated') return 'text-green-600 bg-green-50';
    if (status === 'pending') return 'text-amber-600 bg-amber-50';
    return 'text-blue-600 bg-blue-50';
  };

  const fetchAllRegistrations = async (): Promise<Registration[]> => {
    const { data } = await supabase
      .from('registrations')
      .select('*')
      .order('created_at', { ascending: false });
    return data || [];
  };

  const handleExportCSV = async () => {
    setExporting(true);
    setExportMsg('');
    try {
      const allRegs = await fetchAllRegistrations();
      if (allRegs.length === 0) {
        setExportMsg(t('exportEmpty'));
        setExporting(false);
        setTimeout(() => setExportMsg(''), 3000);
        return;
      }
      const csv = registrationsToCSV(allRegs, locale);
      const date = new Date().toISOString().split('T')[0];
      downloadFile(csv, `drivepro_registrations_${date}.csv`, 'text/csv;charset=utf-8;');
      setExportMsg(t('exportSuccess'));
    } catch {
      setExportMsg(locale === 'fr' ? 'Erreur lors de l\'export' : 'Export error');
    }
    setExporting(false);
    setTimeout(() => setExportMsg(''), 3000);
  };

  const handleExportExcel = async () => {
    setExporting(true);
    setExportMsg('');
    try {
      const allRegs = await fetchAllRegistrations();
      if (allRegs.length === 0) {
        setExportMsg(t('exportEmpty'));
        setExporting(false);
        setTimeout(() => setExportMsg(''), 3000);
        return;
      }
      const xml = registrationsToExcelXML(allRegs, locale);
      const date = new Date().toISOString().split('T')[0];
      downloadFile(xml, `drivepro_registrations_${date}.xls`, 'application/vnd.ms-excel');
      setExportMsg(t('exportSuccess'));
    } catch {
      setExportMsg(locale === 'fr' ? 'Erreur lors de l\'export' : 'Export error');
    }
    setExporting(false);
    setTimeout(() => setExportMsg(''), 3000);
  };

  const statCards = [
    { icon: Users, label: t('totalRegistrations'), value: stats.total, color: 'from-blue-500 to-cyan-400' },
    { icon: CheckCircle2, label: t('paidCount'), value: stats.paid, color: 'from-green-500 to-emerald-400' },
    { icon: AlertCircle, label: t('pendingCount'), value: stats.pending, color: 'from-amber-500 to-orange-400' },
    { icon: TrendingUp, label: t('validatedCount'), value: stats.validated, color: 'from-purple-500 to-pink-400' },
  ];

  if (loading) {
    return (
      <div className="pt-16 min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">{t('agentTitle')}</h1>
          <p className="text-gray-500 mt-2">{t('agentSubtitle')}</p>
        </div>

        {/* Social Connection Section */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sm:p-8 mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-400 flex items-center justify-center">
              <Share2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900">{t('socialConnect')}</h2>
              <p className="text-gray-500 text-sm">{t('socialDesc')}</p>
            </div>
          </div>

          <div className="grid sm:grid-cols-3 gap-4 mt-6">
            {campaigns.map((campaign) => {
              const Icon = platformIcons[campaign.platform] || Link2;
              const colorClass = platformColors[campaign.platform] || 'from-gray-600 to-gray-700';
              return (
                <div key={campaign.id} className="rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all">
                  <div className={`bg-gradient-to-br ${colorClass} p-5`}>
                    <div className="flex items-center justify-between">
                      <Icon className="w-8 h-8 text-white" />
                      <span className="text-white/80 text-xs font-medium capitalize">{campaign.platform}</span>
                    </div>
                    <h3 className="text-white font-semibold mt-3">{campaign.label}</h3>
                  </div>

                  <div className="p-4">
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-900">{campaign.clicks}</div>
                        <div className="text-xs text-gray-500">{t('clicks')}</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{campaign.conversions}</div>
                        <div className="text-xs text-gray-500">{t('conversions')}</div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <a
                        href={campaign.tracked_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-gray-100 text-gray-700 text-sm font-medium hover:bg-gray-200 transition-colors"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        {locale === 'fr' ? 'Ouvrir' : 'Open'}
                      </a>
                      <button
                        onClick={() => copyLink(campaign)}
                        className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-blue-50 text-blue-600 text-sm font-medium hover:bg-blue-100 transition-colors"
                      >
                        {copiedId === campaign.id ? (
                          <><Check className="w-3.5 h-3.5" /> {t('linkCopied')}</>
                        ) : (
                          <><Copy className="w-3.5 h-3.5" /> {t('copyLink')}</>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Connection guide */}
          <div className="mt-6 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-5 border border-blue-100">
            <h4 className="font-semibold text-gray-900 text-sm mb-3">
              {locale === 'fr' ? 'Comment connecter vos réseaux' : 'How to connect your networks'}
            </h4>
            <div className="space-y-2">
              {(locale === 'fr' ? [
                'Copiez le lien traqué de chaque réseau social ci-dessus',
                'Collez-le dans votre bio ou description de profil',
                'Partagez-le dans vos publications et stories',
                'Chaque clic et conversion est automatiquement suivi ici',
              ] : [
                'Copy the tracked link for each social network above',
                'Paste it into your bio or profile description',
                'Share it in your posts and stories',
                'Each click and conversion is automatically tracked here',
              ]).map((step, i) => (
                <div key={i} className="flex items-start gap-3 text-sm text-gray-700">
                  <div className="w-5 h-5 rounded-full bg-blue-500 text-white text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                    {i + 1}
                  </div>
                  <span>{step}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Admin Panel */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sm:p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900">{t('adminPanel')}</h2>
              <p className="text-gray-500 text-sm">{t('adminDesc')}</p>
            </div>
            <div className="ml-auto flex items-center gap-2 text-xs text-green-600 font-medium">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              {locale === 'fr' ? 'Temps réel' : 'Live'}
            </div>
          </div>

          {/* Stat cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {statCards.map((stat, i) => (
              <div key={i} className="rounded-2xl border border-gray-100 p-5">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
                  <stat.icon className="w-5 h-5 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-xs text-gray-500 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Export section */}
          <div className="mb-6 bg-gradient-to-br from-slate-50 to-blue-50 rounded-2xl p-5 border border-blue-100">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                <Download className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 text-sm">{t('exportData')}</h3>
                <p className="text-gray-500 text-xs">{t('exportDesc')}</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <button
                onClick={handleExportCSV}
                disabled={exporting}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white border-2 border-blue-200 text-blue-600 font-medium text-sm hover:bg-blue-50 transition-all disabled:opacity-50"
              >
                {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                {t('exportCSV')}
              </button>
              <button
                onClick={handleExportExcel}
                disabled={exporting}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white border-2 border-green-200 text-green-600 font-medium text-sm hover:bg-green-50 transition-all disabled:opacity-50"
              >
                {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
                {t('exportExcel')}
              </button>
            </div>

            {exportMsg && (
              <div className={`mt-3 flex items-center gap-2 text-sm font-medium ${exportMsg === t('exportSuccess') ? 'text-green-600' : 'text-amber-600'}`}>
                {exportMsg === t('exportSuccess') ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                {exportMsg}
              </div>
            )}
          </div>

          {/* Recent registrations table */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">{t('recentRegistrations')}</h3>
            {registrations.length === 0 ? (
              <div className="text-center py-12 text-gray-400 text-sm">
                {locale === 'fr' ? 'Aucune inscription pour le moment' : 'No registrations yet'}
              </div>
            ) : (
              <div className="overflow-x-auto -mx-4 sm:mx-0">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-100">
                      <th className="text-left py-3 px-2 font-medium text-gray-500">{t('fullName_header')}</th>
                      <th className="text-left py-3 px-2 font-medium text-gray-500 hidden sm:table-cell">{t('country_header')}</th>
                      <th className="text-left py-3 px-2 font-medium text-gray-500">{t('status_header')}</th>
                      <th className="text-left py-3 px-2 font-medium text-gray-500 hidden md:table-cell">{t('date_header')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {registrations.map((reg) => {
                      const c = getCountry(reg.country_code);
                      return (
                        <tr key={reg.id} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                          <td className="py-3 px-2">
                            <div className="font-medium text-gray-800">{reg.full_name}</div>
                            <div className="text-xs text-gray-400">{reg.email}</div>
                          </td>
                          <td className="py-3 px-2 hidden sm:table-cell">
                            <span className="flex items-center gap-1.5 text-gray-700">
                              <span>{c?.flag || '🌍'}</span>
                              <span className="text-xs">{reg.country_code}</span>
                            </span>
                          </td>
                          <td className="py-3 px-2">
                            <div className="flex flex-col gap-1">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold w-fit ${statusColor(reg.payment_status)}`}>
                                {statusLabel(reg.payment_status)}
                              </span>
                              {reg.queue_status !== 'pending' && (
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold w-fit ${statusColor(reg.queue_status)}`}>
                                  {statusLabel(reg.queue_status)}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="py-3 px-2 hidden md:table-cell text-gray-500 text-xs">
                            {new Date(reg.created_at).toLocaleDateString(locale === 'fr' ? 'fr-FR' : 'en-US')}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* CTA */}
        <div className="mt-6 text-center">
          <button
            onClick={() => onNavigate('register')}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.02] transition-all"
          >
            <CreditCard className="w-5 h-5" />
            {t('startRegistration')}
          </button>
        </div>
      </div>
    </div>
  );
}
