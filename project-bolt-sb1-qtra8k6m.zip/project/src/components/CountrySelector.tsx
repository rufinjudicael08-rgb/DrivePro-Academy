import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Search, Check, Globe } from 'lucide-react';
import { useApp } from '@/lib/context';
import { countries } from '@/lib/countries';

export default function CountrySelector() {
  const { country, setCountryCode, locale, t } = useApp();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setSearch('');
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const filtered = countries.filter((c) => {
    const q = search.toLowerCase();
    return (
      c.name_fr.toLowerCase().includes(q) ||
      c.name_en.toLowerCase().includes(q) ||
      c.code.toLowerCase().includes(q)
    );
  });

  const displayName = locale === 'fr' ? country.name_fr : country.name_en;

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors text-sm font-medium text-white border border-white/20"
      >
        <Globe className="w-4 h-4" />
        <span className="text-lg leading-none">{country.flag}</span>
        <span className="hidden sm:inline">{displayName}</span>
        <span className="text-white/60 text-xs">{country.currency}</span>
        <ChevronDown className={`w-4 h-4 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-xl shadow-2xl border border-gray-200 z-50 overflow-hidden">
          <div className="p-3 border-b border-gray-100">
            <div className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-2">
              <Search className="w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder={t('selectCountry')}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-transparent outline-none text-sm flex-1 text-gray-800"
                autoFocus
              />
            </div>
          </div>
          <div className="max-h-72 overflow-y-auto">
            {filtered.map((c) => (
              <button
                key={c.code}
                onClick={() => {
                  setCountryCode(c.code);
                  setOpen(false);
                  setSearch('');
                }}
                className={`w-full flex items-center gap-3 px-4 py-2.5 hover:bg-blue-50 transition-colors text-left ${
                  c.code === country.code ? 'bg-blue-50' : ''
                }`}
              >
                <span className="text-xl">{c.flag}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-gray-800">
                    {locale === 'fr' ? c.name_fr : c.name_en}
                  </div>
                  <div className="text-xs text-gray-500">
                    {c.currency} · {c.code}
                  </div>
                </div>
                {c.code === country.code && <Check className="w-4 h-4 text-blue-600" />}
              </button>
            ))}
            {filtered.length === 0 && (
              <div className="px-4 py-6 text-center text-sm text-gray-400">
                {locale === 'fr' ? 'Aucun pays trouvé' : 'No country found'}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
