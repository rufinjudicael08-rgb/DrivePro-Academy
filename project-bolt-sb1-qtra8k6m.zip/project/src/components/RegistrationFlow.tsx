import { useState, useEffect, useCallback } from 'react';
import {
  User, CreditCard, Clock, BookOpen, Car, Check, Lock, ChevronRight,
  Smartphone, Wallet, Building2, Landmark, Loader2, ArrowLeft, Star,
  HelpCircle, ClipboardList
} from 'lucide-react';
import { useApp } from '@/lib/context';
import { formatFee, convertFee, paymentMethodLabels } from '@/lib/countries';
import { supabase } from '@/lib/supabase';
import type { Registration, PaymentMethod, View } from '@/lib/types';
import QuizComponent from '@/components/QuizComponent';
import { getQuestionsForCourse } from '@/lib/quizData';

interface RegistrationFlowProps {
  onNavigate: (view: View) => void;
  existingRegistration?: Registration | null;
  onRegistrationChange?: (reg: Registration | null) => void;
}

type Step = 'personal' | 'payment' | 'queue' | 'code' | 'driving';

export default function RegistrationFlow({ onNavigate, existingRegistration, onRegistrationChange }: RegistrationFlowProps) {
  const { t, locale, country } = useApp();
  const [registration, setRegistration] = useState<Registration | null>(existingRegistration || null);
  const [currentStep, setCurrentStep] = useState<Step>('personal');

  // Form state
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [formError, setFormError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Payment state
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod | null>(null);
  const [paying, setPaying] = useState(false);

  // Code state
  const [courseResults, setCourseResults] = useState<Record<string, boolean>>({});
  const [examScore, setExamScore] = useState<number | null>(null);

  // Driving instructors
  const [instructors, setInstructors] = useState<any[]>([]);

  useEffect(() => {
    if (existingRegistration) {
      setRegistration(existingRegistration);
      // Determine current step based on registration state
      if (!existingRegistration.file_complete) {
        setCurrentStep('personal');
      } else if (existingRegistration.payment_status === 'pending') {
        setCurrentStep('payment');
      } else if (existingRegistration.queue_status === 'waiting' || existingRegistration.queue_status === 'pending') {
        setCurrentStep('queue');
      } else if (existingRegistration.queue_status === 'in_course' || !existingRegistration.code_exam_passed) {
        setCurrentStep('code');
      } else if (existingRegistration.queue_status === 'validated' && existingRegistration.code_exam_passed) {
        setCurrentStep('driving');
      }
    }
  }, [existingRegistration]);

  useEffect(() => {
    if (registration && registration.code_exam_passed) {
      setCurrentStep('driving');
      loadInstructors();
    }
  }, []);

  const loadInstructors = useCallback(async () => {
    const { data } = await supabase
      .from('instructors')
      .select('*')
      .eq('country_code', country.code);
    setInstructors(data || []);
  }, [country.code]);

  const updateRegistration = useCallback(async (updates: Partial<Registration>) => {
    if (!registration) return;
    const { data, error } = await supabase
      .from('registrations')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', registration.id)
      .select()
      .maybeSingle();
    if (data && !error) {
      setRegistration(data);
      onRegistrationChange?.(data);
    }
  }, [registration, onRegistrationChange]);

  const handleSavePersonal = async () => {
    if (!fullName || !email || !phone || !city) {
      setFormError(t('fillAllFields'));
      return;
    }
    setFormError('');
    setSubmitting(true);

    // Check if registration exists
    const { data: existing } = await supabase
      .from('registrations')
      .select('*')
      .eq('email', email)
      .maybeSingle();

    if (existing) {
      // Update existing
      const { data, error } = await supabase
        .from('registrations')
        .update({
          full_name: fullName,
          phone,
          city,
          birth_date: birthDate || null,
          country_code: country.code,
          locale,
          currency: country.currency,
          file_complete: true,
          updated_at: new Date().toISOString(),
        })
        .eq('id', existing.id)
        .select()
        .maybeSingle();

      if (data && !error) {
        setRegistration(data);
        onRegistrationChange?.(data);
        setCurrentStep('payment');
      }
    } else {
      // Create new
      const { data, error } = await supabase
        .from('registrations')
        .insert({
          full_name: fullName,
          email,
          phone,
          city,
          birth_date: birthDate || null,
          country_code: country.code,
          locale,
          currency: country.currency,
          file_complete: true,
          admin_fee_base: 25000,
        })
        .select()
        .maybeSingle();

      if (data && !error) {
        setRegistration(data);
        onRegistrationChange?.(data);
        setCurrentStep('payment');
      } else {
        setFormError(error?.message || 'Error saving registration');
      }
    }
    setSubmitting(false);
  };

  const handlePay = async () => {
    if (!selectedPayment || !registration) return;
    setPaying(true);

    // Simulate payment processing
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Count existing paid registrations for queue number
    const { count } = await supabase
      .from('registrations')
      .select('*', { count: 'exact', head: true })
      .eq('payment_status', 'paid');

    const queueNumber = (count || 0) + 1;
    const queuePosition = queueNumber;

    await updateRegistration({
      payment_status: 'paid',
      payment_method: selectedPayment,
      queue_number: queueNumber,
      queue_position: queuePosition,
      queue_status: 'waiting',
    });

    setPaying(false);
    setCurrentStep('queue');
  };

  const handleEnterCode = async () => {
    if (!registration) return;
    await updateRegistration({ queue_status: 'in_course' });
    setCurrentStep('code');
  };

  const handleValidateCode = async () => {
    if (!registration) return;
    const passed = examScore !== null && examScore >= 35;
    await updateRegistration({
      code_exam_score: examScore || 0,
      code_exam_passed: passed,
      queue_status: passed ? 'validated' : 'in_course',
    });
    if (passed) {
      setCurrentStep('driving');
      loadInstructors();
    }
  };

  const simulateExam = () => {
    // Simulate exam with 40 questions, random score
    const score = Math.floor(Math.random() * 15) + 30; // 30-44 out of 40... let's make it realistic
    const finalScore = Math.min(score, 40);
    setExamScore(finalScore);
  };

  const steps: { key: Step; label: string; icon: typeof User }[] = [
    { key: 'personal', label: t('stepPersonal'), icon: User },
    { key: 'payment', label: t('stepPayment'), icon: CreditCard },
    { key: 'queue', label: t('stepQueue'), icon: Clock },
    { key: 'code', label: t('stepCode'), icon: BookOpen },
    { key: 'driving', label: t('stepDriving'), icon: Car },
  ];

  const currentStepIndex = steps.findIndex((s) => s.key === currentStep);

  const isStepUnlocked = (step: Step): boolean => {
    if (!registration) return step === 'personal';
    if (step === 'personal') return true;
    if (step === 'payment') return registration.file_complete;
    if (step === 'queue') return registration.payment_status === 'paid';
    if (step === 'code') return registration.payment_status === 'paid';
    if (step === 'driving') return registration.code_exam_passed && registration.queue_status === 'validated';
    return false;
  };

  const paymentIcons: Record<PaymentMethod, typeof CreditCard> = {
    card: CreditCard,
    mobile_money: Smartphone,
    paypal: Wallet,
    sepa: Building2,
    bank_transfer: Landmark,
  };

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-2 text-gray-500 hover:text-gray-800 text-sm mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          {t('home')}
        </button>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">{t('registrationTitle')}</h1>
          <p className="text-gray-500 mt-2">{t('registrationSubtitle')}</p>
        </div>

        {/* Progress bar */}
        <div className="mb-10">
          <div className="flex items-center justify-between gap-1 overflow-x-auto pb-2">
            {steps.map((step, i) => {
              const unlocked = isStepUnlocked(step.key);
              const isCurrent = step.key === currentStep;
              const isPast = i < currentStepIndex;
              return (
                <div key={step.key} className="flex items-center flex-1 min-w-[100px]">
                  <div className="flex flex-col items-center gap-2 flex-1">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                        isCurrent
                          ? 'bg-gradient-to-br from-blue-500 to-cyan-400 text-white shadow-lg shadow-blue-500/30 scale-110'
                          : isPast
                          ? 'bg-green-500 text-white'
                          : unlocked
                          ? 'bg-white border-2 border-blue-300 text-blue-500'
                          : 'bg-gray-200 text-gray-400'
                      }`}
                    >
                      {isPast ? <Check className="w-5 h-5" /> : !unlocked ? <Lock className="w-4 h-4" /> : <step.icon className="w-5 h-5" />}
                    </div>
                    <span className={`text-[11px] text-center font-medium ${isCurrent ? 'text-blue-600' : isPast ? 'text-green-600' : 'text-gray-400'}`}>
                      {step.label}
                    </span>
                  </div>
                  {i < steps.length - 1 && (
                    <div className={`h-0.5 flex-1 mx-1 -mt-6 rounded-full ${i < currentStepIndex ? 'bg-green-500' : 'bg-gray-200'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Step content */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sm:p-8">
          {/* Step 1: Personal Info */}
          {currentStep === 'personal' && (
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-1">{t('stepPersonal')}</h2>
              <p className="text-gray-500 text-sm mb-6">{locale === 'fr' ? 'Renseignez vos informations personnelles' : 'Enter your personal information'}</p>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{t('fullName')} *</label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all text-gray-800"
                    placeholder={locale === 'fr' ? 'Jean Dupont' : 'John Doe'}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{t('email')} *</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all text-gray-800"
                    placeholder="jean.dupont@email.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{t('phone')} *</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all text-gray-800"
                    placeholder="+33 6 12 34 56 78"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{t('city')} *</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all text-gray-800"
                    placeholder="Paris"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{t('birthDate')}</label>
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all text-gray-800"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{t('country')}</label>
                  <div className="px-4 py-3 rounded-xl border border-gray-200 bg-gray-50 flex items-center gap-2">
                    <span className="text-xl">{country.flag}</span>
                    <span className="text-gray-800">{locale === 'fr' ? country.name_fr : country.name_en}</span>
                    <span className="text-gray-400 text-sm">· {country.currency}</span>
                  </div>
                </div>
              </div>

              {formError && (
                <div className="mt-4 p-3 rounded-lg bg-red-50 text-red-600 text-sm">{formError}</div>
              )}

              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleSavePersonal}
                  disabled={submitting}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.02] transition-all disabled:opacity-50"
                >
                  {submitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <ChevronRight className="w-5 h-5" />}
                  {t('saveAndContinue')}
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Payment */}
          {currentStep === 'payment' && (
            <div>
              {!registration?.file_complete ? (
                <LockedNotice text={t('paymentLocked')} onBack={() => setCurrentStep('personal')} t={t} />
              ) : (
                <div>
                  <h2 className="text-xl font-bold text-gray-900 mb-1">{t('stepPayment')}</h2>
                  <p className="text-gray-500 text-sm mb-6">{t('feeDescription')}</p>

                  <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-100 mb-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-gray-600 text-sm">{t('adminFee')}</div>
                        <div className="text-3xl font-bold text-gray-900 mt-1">{formatFee(country)}</div>
                        <div className="text-gray-500 text-xs mt-1">
                          {locale === 'fr' ? 'Base: 250 €' : 'Base: €250'} · {country.currency}
                        </div>
                      </div>
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg">
                        <CreditCard className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  </div>

                  <h3 className="text-sm font-semibold text-gray-700 mb-3">{t('selectPaymentMethod')}</h3>
                  <div className="grid sm:grid-cols-2 gap-3 mb-6">
                    {country.paymentMethods.map((pm) => {
                      const Icon = paymentIcons[pm];
                      const labels = paymentMethodLabels[pm];
                      const isSelected = selectedPayment === pm;
                      return (
                        <button
                          key={pm}
                          onClick={() => setSelectedPayment(pm)}
                          className={`flex items-center gap-3 p-4 rounded-xl border-2 transition-all text-left ${
                            isSelected
                              ? 'border-blue-400 bg-blue-50'
                              : 'border-gray-200 hover:border-gray-300 bg-white'
                          }`}
                        >
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${isSelected ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-500'}`}>
                            <Icon className="w-5 h-5" />
                          </div>
                          <span className={`font-medium ${isSelected ? 'text-blue-700' : 'text-gray-700'}`}>
                            {labels[locale as 'fr' | 'en']}
                          </span>
                          {isSelected && <Check className="w-5 h-5 text-blue-500 ml-auto" />}
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex justify-between items-center">
                    <button
                      onClick={() => setCurrentStep('personal')}
                      className="text-gray-500 hover:text-gray-800 text-sm flex items-center gap-2"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      {t('back')}
                    </button>
                    <button
                      onClick={handlePay}
                      disabled={!selectedPayment || paying}
                      className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-green-500 to-emerald-400 text-white font-semibold shadow-lg shadow-green-500/30 hover:scale-[1.02] transition-all disabled:opacity-50"
                    >
                      {paying ? <Loader2 className="w-5 h-5 animate-spin" /> : <Check className="w-5 h-5" />}
                      {paying ? t('paymentProcessing') : `${t('payNow')} — ${formatFee(country)}`}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 3: Queue */}
          {currentStep === 'queue' && (
            <div>
              {registration?.payment_status !== 'paid' ? (
                <LockedNotice text={t('queueLocked')} onBack={() => setCurrentStep('payment')} t={t} />
              ) : (
                <div className="text-center">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-blue-500/30">
                    <Clock className="w-10 h-10 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('inQueue')}</h2>
                  <p className="text-gray-500 mb-8">{locale === 'fr' ? 'Vous êtes en file d\'attente' : 'You are in the queue'}</p>

                  <div className="grid sm:grid-cols-3 gap-4 max-w-2xl mx-auto mb-8">
                    <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-6 border border-blue-100">
                      <div className="text-gray-500 text-sm mb-1">{t('queueNumber')}</div>
                      <div className="text-4xl font-bold text-blue-600">#{registration?.queue_number}</div>
                    </div>
                    <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6 border border-amber-100">
                      <div className="text-gray-500 text-sm mb-1">{t('queuePosition')}</div>
                      <div className="text-4xl font-bold text-amber-600">{registration?.queue_position}</div>
                    </div>
                    <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-100">
                      <div className="text-gray-500 text-sm mb-1">{t('estimatedWait')}</div>
                      <div className="text-2xl font-bold text-green-600">
                        {locale === 'fr' ? '~2 sem.' : '~2 wks'}
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 border border-green-200 rounded-xl p-4 max-w-md mx-auto mb-8">
                    <div className="flex items-center justify-center gap-2 text-green-700">
                      <Check className="w-5 h-5" />
                      <span className="font-medium">{t('paymentSuccess')}</span>
                    </div>
                  </div>

                  <button
                    onClick={handleEnterCode}
                    className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.02] transition-all"
                  >
                    <BookOpen className="w-5 h-5" />
                    {locale === 'fr' ? 'Accéder aux cours de code' : 'Access theory courses'}
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Step 4: Code */}
          {currentStep === 'code' && (
            <CodeStep
              registration={registration}
              t={t}
              locale={locale}
              courseResults={courseResults}
              setCourseResults={setCourseResults}
              examScore={examScore}
              simulateExam={simulateExam}
              onValidate={handleValidateCode}
            />
          )}

          {/* Step 5: Driving */}
          {currentStep === 'driving' && (
            <DrivingStep
              registration={registration}
              t={t}
              locale={locale}
              instructors={instructors}
              onNavigate={onNavigate}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function LockedNotice({ text, onBack, t }: { text: string; onBack: () => void; t: (k: any) => string }) {
  return (
    <div className="text-center py-12">
      <div className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center mx-auto mb-4">
        <Lock className="w-8 h-8 text-gray-400" />
      </div>
      <p className="text-gray-500 mb-6 max-w-md mx-auto">{text}</p>
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gray-100 text-gray-700 font-medium hover:bg-gray-200 transition-all"
      >
        <ArrowLeft className="w-4 h-4" />
        {t('back')}
      </button>
    </div>
  );
}

function CodeStep({
  registration, t, locale, courseResults, setCourseResults, examScore, simulateExam, onValidate
}: any) {
  const [courses, setCourses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCourse, setActiveCourse] = useState<any | null>(null);
  const [quizMode, setQuizMode] = useState(false);
  const [quizQuestions, setQuizQuestions] = useState<any[]>([]);

  useEffect(() => {
    async function load() {
      const { data } = await supabase.from('code_courses').select('*').order('lesson_order');
      setCourses(data || []);
      setLoading(false);
    }
    load();
  }, []);

  const completedCount = Object.keys(courseResults).length;
  const allLessonsDone = courses.filter((c) => !c.is_exam).every((c) => courseResults[c.id]);

  const startQuizForCourse = (course: any) => {
    const questions = getQuestionsForCourse(course.lesson_order);
    if (questions.length > 0) {
      setQuizQuestions(questions);
      setQuizMode(true);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-blue-500" /></div>;
  }

  if (quizMode && quizQuestions.length > 0) {
    return (
      <QuizComponent
        questions={quizQuestions}
        locale={locale}
        t={t}
        onExit={() => {
          setQuizMode(false);
          setQuizQuestions([]);
        }}
      />
    );
  }

  if (activeCourse) {
    return (
      <div>
        <button
          onClick={() => setActiveCourse(null)}
          className="flex items-center gap-2 text-gray-500 hover:text-gray-800 text-sm mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          {locale === 'fr' ? 'Retour aux cours' : 'Back to courses'}
        </button>

        <div className="bg-gradient-to-br from-slate-50 to-blue-50 rounded-2xl p-8 border border-blue-100">
          <div className="flex items-center gap-3 mb-4">
            {activeCourse.is_exam && (
              <div className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-xs font-semibold">{t('exam')}</div>
            )}
            <h2 className="text-2xl font-bold text-gray-900">
              {locale === 'fr' ? activeCourse.title_fr : activeCourse.title_en}
            </h2>
          </div>
          <p className="text-gray-600 mb-6">{locale === 'fr' ? activeCourse.description_fr : activeCourse.description_en}</p>

          {activeCourse.is_exam ? (
            <div className="text-center py-8">
              <p className="text-gray-600 mb-6">
                {locale === 'fr' ? 'Examen blanc de 40 questions. Vous devez obtenir au moins 35/40 pour réussir.' : 'Mock exam with 40 questions. You need at least 35/40 to pass.'}
              </p>
              {examScore === null ? (
                <button
                  onClick={simulateExam}
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-400 text-white font-semibold shadow-lg hover:scale-[1.02] transition-all"
                >
                  <BookOpen className="w-5 h-5" />
                  {t('passExam')}
                </button>
              ) : (
                <div>
                  <div className={`text-5xl font-bold mb-2 ${examScore >= 35 ? 'text-green-500' : 'text-red-500'}`}>
                    {examScore}/40
                  </div>
                  <p className={`font-medium mb-6 ${examScore >= 35 ? 'text-green-600' : 'text-red-600'}`}>
                    {examScore >= 35 ? t('examPassed') : t('examFailed')}
                  </p>
                  <button
                    onClick={onValidate}
                    className={`inline-flex items-center gap-2 px-8 py-4 rounded-xl font-semibold shadow-lg transition-all ${
                      examScore >= 35
                        ? 'bg-gradient-to-r from-green-500 to-emerald-400 text-white hover:scale-[1.02]'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {examScore >= 35 ? <><Check className="w-5 h-5" /> {t('validateCode')}</> : t('back')}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="py-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-3">
                  <BookOpen className="w-8 h-8 text-blue-600" />
                </div>
                <p className="text-gray-600 text-sm">{t('duration')}: {activeCourse.duration_minutes} {t('minutes')}</p>
              </div>

              {/* Quiz button */}
              {getQuestionsForCourse(activeCourse.lesson_order).length > 0 && (
                <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-5 border border-blue-100 mb-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                      <HelpCircle className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 text-sm">{t('practiceQuiz')}</h4>
                      <p className="text-gray-500 text-xs">{t('quizDesc')}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => startQuizForCourse(activeCourse)}
                    className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.01] transition-all"
                  >
                    <ClipboardList className="w-5 h-5" />
                    {t('startQuiz')}
                  </button>
                </div>
              )}

              {/* Complete button */}
              <button
                onClick={() => {
                  setCourseResults({ ...courseResults, [activeCourse.id]: true });
                  setActiveCourse(null);
                }}
                className="w-full inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-white border-2 border-green-300 text-green-600 font-semibold hover:bg-green-50 transition-all"
              >
                <Check className="w-5 h-5" />
                {locale === 'fr' ? 'Marquer comme terminé' : 'Mark as completed'}
              </button>
            </div>
          )
        </div>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-xl font-bold text-gray-900 mb-1">{t('codeCourses')}</h2>
      <p className="text-gray-500 text-sm mb-2">{t('codeCoursesDesc')}</p>
      <div className="flex items-center gap-2 text-sm text-gray-500 mb-6">
        <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all" style={{ width: `${(completedCount / courses.length) * 100}%` }} />
        </div>
        <span>{completedCount}/{courses.length}</span>
      </div>

      <div className="space-y-3">
        {courses.map((course, i) => {
          const isDone = courseResults[course.id];
          const isExam = course.is_exam;
          const locked = isExam && !allLessonsDone;
          const hasQuiz = getQuestionsForCourse(course.lesson_order).length > 0;
          return (
            <button
              key={course.id}
              onClick={() => !locked && setActiveCourse(course)}
              disabled={locked}
              className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-left ${
                locked
                  ? 'border-gray-100 bg-gray-50 cursor-not-allowed opacity-60'
                  : isDone
                  ? 'border-green-200 bg-green-50'
                  : 'border-gray-200 hover:border-blue-300 bg-white'
              }`}
            >
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${isDone ? 'bg-green-500' : locked ? 'bg-gray-200' : isExam ? 'bg-amber-100' : 'bg-blue-100'}`}>
                {isDone ? <Check className="w-5 h-5 text-white" /> : locked ? <Lock className="w-4 h-4 text-gray-400" /> : isExam ? <Star className="w-5 h-5 text-amber-600" /> : <BookOpen className="w-5 h-5 text-blue-600" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-medium text-gray-800 text-sm">{locale === 'fr' ? course.title_fr : course.title_en}</span>
                  {isExam && <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 text-[10px] font-semibold">{t('exam')}</span>}
                  {hasQuiz && !isExam && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-semibold">
                      <HelpCircle className="w-3 h-3" />
                      {t('practiceQuiz')}
                    </span>
                  )}
                </div>
                <div className="text-xs text-gray-400 mt-0.5">{t('duration')}: {course.duration_minutes} {t('minutes')}</div>
              </div>
              {!locked && <ChevronRight className="w-5 h-5 text-gray-300" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function DrivingStep({ registration, t, locale, instructors, onNavigate }: any) {
  if (!registration?.code_exam_passed || registration?.queue_status !== 'validated') {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 rounded-full bg-gray-200 flex items-center justify-center mx-auto mb-4">
          <Lock className="w-8 h-8 text-gray-400" />
        </div>
        <p className="text-gray-500 mb-6 max-w-md mx-auto">{t('drivingLocked')}</p>
      </div>
    );
  }

  return (
    <div className="text-center">
      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-500 to-emerald-400 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-500/30">
        <Car className="w-10 h-10 text-white" />
      </div>
      <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('drivingUnlocked')}</h2>
      <p className="text-gray-500 mb-8 max-w-lg mx-auto">{t('drivingDesc')}</p>

      {instructors.length === 0 ? (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 max-w-md mx-auto">
          <p className="text-amber-700">
            {locale === 'fr'
              ? 'Aucun moniteur disponible dans votre pays pour le moment. Notre équipe vous contactera bientôt.'
              : 'No instructor available in your country yet. Our team will contact you soon.'}
          </p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4 max-w-2xl mx-auto">
          {instructors.map((inst: any) => (
            <div key={inst.id} className="bg-white rounded-2xl border-2 border-gray-100 p-6 text-left hover:shadow-lg transition-all">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                  <User className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-gray-900">{inst.name}</div>
                  <div className="text-xs text-gray-500">{inst.city}, {inst.country_code}</div>
                </div>
                <div className="ml-auto flex items-center gap-1">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="text-sm font-medium text-gray-700">{inst.rating}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <a
                  href={`tel:${inst.phone}`}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-50 text-blue-600 font-medium text-sm hover:bg-blue-100 transition-colors"
                >
                  <Smartphone className="w-4 h-4" />
                  {t('callInstructor')}
                </a>
                <a
                  href={`https://wa.me/${inst.whatsapp.replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-green-50 text-green-600 font-medium text-sm hover:bg-green-100 transition-colors"
                >
                  <Smartphone className="w-4 h-4" />
                  WhatsApp
                </a>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-8">
        <button
          onClick={() => onNavigate('candidate')}
          className="text-blue-600 font-medium text-sm hover:underline"
        >
          {locale === 'fr' ? 'Accéder à mon espace candidat' : 'Access my candidate space'}
        </button>
      </div>
    </div>
  );
}
