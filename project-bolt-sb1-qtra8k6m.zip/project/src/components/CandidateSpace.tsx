import { useState, useEffect } from 'react';
import {
  User, Mail, Lock, Loader2, ArrowRight, Clock, BookOpen, Car,
  Check, Phone, Star, ChevronRight, CreditCard, AlertCircle
} from 'lucide-react';
import { useApp } from '@/lib/context';
import { supabase } from '@/lib/supabase';
import { formatFee } from '@/lib/countries';
import { getCountry } from '@/lib/countries';
import type { Registration, View } from '@/lib/types';

export default function CandidateSpace({ onNavigate }: { onNavigate: (view: View) => void }) {
  const { t, locale, country } = useApp();
  const [email, setEmail] = useState('');
  const [registration, setRegistration] = useState<Registration | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [courses, setCourses] = useState<any[]>([]);
  const [instructor, setInstructor] = useState<any | null>(null);

  useEffect(() => {
    async function loadCourses() {
      const { data } = await supabase.from('code_courses').select('*').order('lesson_order');
      setCourses(data || []);
    }
    loadCourses();
  }, []);

  const findRegistration = async () => {
    if (!email) return;
    setLoading(true);
    setError('');
    const { data, error } = await supabase
      .from('registrations')
      .select('*')
      .eq('email', email)
      .maybeSingle();

    if (error || !data) {
      setError(t('noRegistration'));
      setRegistration(null);
    } else {
      setRegistration(data);
      if (data.instructor_id) {
        const { data: inst } = await supabase
          .from('instructors')
          .select('*')
          .eq('id', data.instructor_id)
          .maybeSingle();
        setInstructor(inst);
      } else if (data.code_exam_passed && data.queue_status === 'validated') {
        // Find instructor for the country
        const { data: inst } = await supabase
          .from('instructors')
          .select('*')
          .eq('country_code', data.country_code)
          .limit(1)
          .maybeSingle();
        setInstructor(inst);
      }
    }
    setLoading(false);
  };

  const regCountry = registration ? getCountry(registration.country_code) : country;

  const progressSteps = [
    { key: 'file', label: t('stepPersonal'), done: registration?.file_complete },
    { key: 'payment', label: t('stepPayment'), done: registration?.payment_status === 'paid' },
    { key: 'queue', label: t('stepQueue'), done: registration?.queue_status === 'waiting' || registration?.queue_status === 'in_course' || registration?.queue_status === 'validated' },
    { key: 'code', label: t('stepCode'), done: registration?.code_exam_passed },
    { key: 'driving', label: t('stepDriving'), done: registration?.queue_status === 'validated' && registration?.code_exam_passed },
  ];

  const statusLabel = (status: string) => {
    const map: Record<string, string> = {
      pending: t('statusPending'),
      paid: t('statusPaid'),
      waiting: t('statusWaiting'),
      in_course: t('statusInCourse'),
      validated: t('statusValidated'),
    };
    return map[status] || status;
  };

  if (!registration) {
    return (
      <div className="pt-16 min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full mx-4">
          <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center mb-6 mx-auto">
              <User className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 text-center mb-2">{t('candidateWelcome')}</h1>
            <p className="text-gray-500 text-center text-sm mb-6">{t('enterEmail')}</p>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">{t('email')}</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && findRegistration()}
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition-all text-gray-800"
                    placeholder="jean.dupont@email.com"
                  />
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-50 text-amber-700 text-sm">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  {error}
                </div>
              )}

              <button
                onClick={findRegistration}
                disabled={loading || !email}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.02] transition-all disabled:opacity-50"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowRight className="w-5 h-5" />}
                {t('accessSpace')}
              </button>

              <div className="text-center pt-2">
                <button
                  onClick={() => onNavigate('register')}
                  className="text-blue-600 text-sm hover:underline"
                >
                  {t('startByRegistering')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const canAccessCode = registration.payment_status === 'paid';
  const canAccessDriving = registration.code_exam_passed && registration.queue_status === 'validated';

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header card */}
        <div className="bg-gradient-to-br from-slate-900 to-blue-950 rounded-2xl p-6 sm:p-8 mb-6 text-white">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                <User className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold">{registration.full_name}</h1>
                <p className="text-white/60 text-sm">{registration.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`px-3 py-1.5 rounded-full text-xs font-semibold ${
                registration.payment_status === 'paid' ? 'bg-green-500/20 text-green-300' : 'bg-amber-500/20 text-amber-300'
              }`}>
                {statusLabel(registration.payment_status)}
              </span>
              <span className="px-3 py-1.5 rounded-full text-xs font-semibold bg-blue-500/20 text-blue-300">
                {statusLabel(registration.queue_status)}
              </span>
            </div>
          </div>
        </div>

        {/* Progress overview */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4">{t('yourProgress')}</h2>
          <div className="flex items-center justify-between gap-1 overflow-x-auto pb-2">
            {progressSteps.map((step, i) => (
              <div key={step.key} className="flex items-center flex-1 min-w-[80px]">
                <div className="flex flex-col items-center gap-2 flex-1">
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center ${
                    step.done ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-400'
                  }`}>
                    {step.done ? <Check className="w-4 h-4" /> : <span className="text-xs font-bold">{i + 1}</span>}
                  </div>
                  <span className={`text-[10px] text-center font-medium ${step.done ? 'text-green-600' : 'text-gray-400'}`}>
                    {step.label}
                  </span>
                </div>
                {i < progressSteps.length - 1 && (
                  <div className={`h-0.5 flex-1 mx-1 -mt-6 rounded-full ${step.done ? 'bg-green-500' : 'bg-gray-200'}`} />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Queue info */}
          <div className={`bg-white rounded-2xl shadow-sm border p-6 ${registration.payment_status === 'paid' ? 'border-gray-100' : 'border-gray-100 opacity-60'}`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <h3 className="font-bold text-gray-900">{t('stepQueue')}</h3>
            </div>
            {registration.payment_status === 'paid' ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-500 text-sm">{t('queueNumber')}</span>
                  <span className="font-bold text-blue-600 text-lg">#{registration.queue_number}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-500 text-sm">{t('queuePosition')}</span>
                  <span className="font-bold text-amber-600 text-lg">{registration.queue_position}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-500 text-sm">{t('queueStatus')}</span>
                  <span className="font-semibold text-gray-700">{statusLabel(registration.queue_status)}</span>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <Lock className="w-4 h-4" />
                {t('queueLocked')}
              </div>
            )}
            {registration.payment_status === 'pending' && (
              <button
                onClick={() => onNavigate('register')}
                className="mt-4 text-sm text-blue-600 hover:underline flex items-center gap-1"
              >
                {locale === 'fr' ? 'Finaliser le paiement' : 'Finalize payment'}
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Payment info */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="font-bold text-gray-900">{t('stepPayment')}</h3>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-500 text-sm">{t('adminFee')}</span>
                <span className="font-bold text-gray-900">
                  {regCountry ? formatFee(regCountry) : '25000'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500 text-sm">{t('paymentMethod')}</span>
                <span className="text-gray-700 text-sm capitalize">{registration.payment_method?.replace('_', ' ') || '—'}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-500 text-sm">{locale === 'fr' ? 'Statut' : 'Status'}</span>
                <span className={`font-semibold text-sm ${registration.payment_status === 'paid' ? 'text-green-600' : 'text-amber-600'}`}>
                  {statusLabel(registration.payment_status)}
                </span>
              </div>
            </div>
          </div>

          {/* Code courses */}
          <div className={`bg-white rounded-2xl shadow-sm border p-6 ${canAccessCode ? 'border-gray-100' : 'border-gray-100 opacity-60'}`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-purple-100 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-purple-600" />
              </div>
              <h3 className="font-bold text-gray-900">{t('codeCourses')}</h3>
            </div>
            {canAccessCode ? (
              <div className="space-y-2">
                {courses.slice(0, 4).map((c) => (
                  <div key={c.id} className="flex items-center gap-2 text-sm text-gray-600">
                    <BookOpen className="w-4 h-4 text-gray-300 flex-shrink-0" />
                    <span className="truncate">{locale === 'fr' ? c.title_fr : c.title_en}</span>
                    {c.is_exam && <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 text-[10px] font-semibold flex-shrink-0">{t('exam')}</span>}
                  </div>
                ))}
                {registration.code_exam_score > 0 && (
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                    <span className="text-gray-500 text-sm">{t('score')}</span>
                    <span className={`font-bold ${registration.code_exam_passed ? 'text-green-600' : 'text-red-500'}`}>
                      {registration.code_exam_score}/40
                    </span>
                  </div>
                )}
                <button
                  onClick={() => onNavigate('register')}
                  className="mt-3 text-sm text-blue-600 hover:underline flex items-center gap-1"
                >
                  {locale === 'fr' ? 'Continuer les cours' : 'Continue courses'}
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <Lock className="w-4 h-4" />
                {t('codeLocked')}
              </div>
            )}
          </div>

          {/* Driving / Instructor */}
          <div className={`bg-white rounded-2xl shadow-sm border p-6 ${canAccessDriving ? 'border-gray-100' : 'border-gray-100 opacity-60'}`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
                <Car className="w-5 h-5 text-green-600" />
              </div>
              <h3 className="font-bold text-gray-900">{t('stepDriving')}</h3>
            </div>
            {canAccessDriving ? (
              instructor ? (
                <div>
                  <p className="text-gray-600 text-sm mb-4">{t('drivingDesc')}</p>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold text-gray-900">{instructor.name}</div>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                        {instructor.rating} · {instructor.city}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href={`tel:${instructor.phone}`}
                      className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-blue-50 text-blue-600 font-medium text-sm hover:bg-blue-100 transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                      {t('callInstructor')}
                    </a>
                    <a
                      href={`https://wa.me/${instructor.whatsapp.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-green-50 text-green-600 font-medium text-sm hover:bg-green-100 transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                      WhatsApp
                    </a>
                  </div>
                </div>
              ) : (
                <p className="text-gray-400 text-sm">
                  {locale === 'fr' ? 'Aucun moniteur disponible dans votre pays pour le moment.' : 'No instructor available in your country yet.'}
                </p>
              )
            ) : (
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <Lock className="w-4 h-4" />
                {t('drivingLocked')}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
