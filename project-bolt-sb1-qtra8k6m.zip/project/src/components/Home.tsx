import { Car, Globe, BookOpen, Users, ShieldCheck, ArrowRight, Star, GraduationCap, Clock, CreditCard } from 'lucide-react';
import { useApp } from '@/lib/context';
import { formatFee, convertFee } from '@/lib/countries';
import type { View } from '@/lib/types';

export default function Home({ onNavigate }: { onNavigate: (view: View) => void }) {
  const { t, locale, country } = useApp();

  const features = [
    { icon: Globe, title: t('feature1Title'), desc: t('feature1Desc') },
    { icon: BookOpen, title: t('feature2Title'), desc: t('feature2Desc') },
    { icon: Users, title: t('feature3Title'), desc: t('feature3Desc') },
    { icon: ShieldCheck, title: t('feature4Title'), desc: t('feature4Desc') },
  ];

  const stats = [
    { value: '60+', label: t('statCountries') },
    { value: '12,000+', label: t('statStudents') },
    { value: '94%', label: t('statSuccess') },
    { value: '150+', label: t('statInstructors') },
  ];

  const steps = [
    { icon: CreditCard, title: t('stepPersonal'), desc: locale === 'fr' ? 'Remplissez votre dossier' : 'Fill in your file' },
    { icon: CreditCard, title: t('stepPayment'), desc: locale === 'fr' ? 'Payez les frais (25000)' : 'Pay the fee (25000)' },
    { icon: Clock, title: t('stepQueue'), desc: locale === 'fr' ? 'Rejoignez la file' : 'Join the queue' },
    { icon: BookOpen, title: t('stepCode'), desc: locale === 'fr' ? 'Passez le code' : 'Pass the theory' },
    { icon: Car, title: t('stepDriving'), desc: locale === 'fr' ? 'Leçons pratiques' : 'Practical lessons' },
  ];

  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="relative overflow-hidden bg-slate-900 min-h-[640px] flex items-center">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-blue-950" />
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3" />
          <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/4" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-400/20 text-blue-300 text-xs font-medium mb-6">
                <Star className="w-3.5 h-3.5 fill-current" />
                {t('trustedWorldwide')}
              </div>
              <h1 className="text-5xl sm:text-6xl font-bold text-white leading-[1.1] mb-4">
                {t('heroTitle')}
              </h1>
              <p className="text-xl text-blue-300 font-medium mb-4">{t('heroSubtitle')}</p>
              <p className="text-white/70 text-lg leading-relaxed mb-8 max-w-xl">{t('heroDescription')}</p>

              <div className="flex flex-wrap gap-4">
                <button
                  onClick={() => onNavigate('register')}
                  className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:shadow-blue-500/50 hover:scale-[1.02] transition-all"
                >
                  {t('startRegistration')}
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
                <button
                  onClick={() => onNavigate('candidate')}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white/10 border border-white/20 text-white font-semibold hover:bg-white/15 transition-all"
                >
                  {t('exploreCourses')}
                </button>
              </div>

              <div className="mt-8 flex items-center gap-4 text-sm text-white/60">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-green-400" />
                  <span>{t('footerLicense')}</span>
                </div>
                <div className="w-px h-4 bg-white/20" />
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-blue-400" />
                  <span>{locale === 'fr' ? 'Pays actuel' : 'Current country'}: {country.flag} {locale === 'fr' ? country.name_fr : country.name_en}</span>
                </div>
              </div>
            </div>

            <div className="hidden lg:block">
              <div className="relative">
                <div className="bg-white/5 backdrop-blur-xl rounded-3xl border border-white/10 p-8 shadow-2xl">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                      <GraduationCap className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-white font-semibold">{t('adminFee')}</div>
                      <div className="text-white/50 text-sm">{t('feeDescription')}</div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-blue-600/20 to-cyan-500/20 rounded-2xl p-6 mb-6">
                    <div className="text-white/60 text-sm mb-1">{locale === 'fr' ? 'Frais pour' : 'Fee for'} {country.flag} {locale === 'fr' ? country.name_fr : country.name_en}</div>
                    <div className="text-4xl font-bold text-white">{formatFee(country)}</div>
                    <div className="text-white/50 text-sm mt-1">
                      {locale === 'fr' ? 'Base: 250 €' : 'Base: €250'} · {country.currency}
                    </div>
                  </div>

                  <div className="space-y-3">
                    {country.paymentMethods.slice(0, 4).map((pm) => (
                      <div key={pm} className="flex items-center gap-3 text-white/80 text-sm">
                        <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
                          {pm === 'card' && <CreditCard className="w-4 h-4" />}
                          {pm === 'mobile_money' && <Car className="w-4 h-4" />}
                          {pm === 'paypal' && <CreditCard className="w-4 h-4" />}
                          {pm === 'sepa' && <CreditCard className="w-4 h-4" />}
                          {pm === 'bank_transfer' && <CreditCard className="w-4 h-4" />}
                        </div>
                        <span className="capitalize">{pm.replace('_', ' ')}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="absolute -top-6 -right-6 w-24 h-24 bg-gradient-to-br from-blue-400 to-cyan-300 rounded-2xl opacity-20 blur-2xl" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-white py-16 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-4xl font-bold bg-gradient-to-br from-blue-600 to-cyan-500 bg-clip-text text-transparent">{stat.value}</div>
                <div className="text-gray-500 text-sm mt-2">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 text-center mb-12">{t('featuresTitle')}</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <div
                key={i}
                className="group bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-xl hover:border-blue-200 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 text-center mb-4">
            {locale === 'fr' ? 'Comment ça marche' : 'How it works'}
          </h2>
          <p className="text-gray-500 text-center mb-12 max-w-2xl mx-auto">
            {locale === 'fr'
              ? 'Un parcours clair et verrouillé, étape par étape, jusqu\'à l\'examen officiel.'
              : 'A clear, locked journey, step by step, all the way to the official exam.'}
          </p>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {steps.map((step, i) => (
              <div key={i} className="relative">
                <div className="bg-gradient-to-br from-slate-50 to-blue-50 rounded-2xl p-5 border border-blue-100 h-full">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-sm">
                      <step.icon className="w-5 h-5 text-blue-600" />
                    </div>
                    <span className="text-3xl font-bold text-blue-100">{i + 1}</span>
                  </div>
                  <h3 className="font-semibold text-gray-900 text-sm mb-1">{step.title}</h3>
                  <p className="text-gray-500 text-xs">{step.desc}</p>
                </div>
                {i < steps.length - 1 && (
                  <ArrowRight className="hidden md:block absolute top-1/2 -right-2 w-4 h-4 text-gray-300 -translate-y-1/2 z-10" />
                )}
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button
              onClick={() => onNavigate('register')}
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.02] transition-all"
            >
              {t('startRegistration')}
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
