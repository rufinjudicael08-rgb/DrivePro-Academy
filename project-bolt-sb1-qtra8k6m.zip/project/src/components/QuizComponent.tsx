import { useState } from 'react';
import {
  Check, X, ChevronRight, RotateCcw, ArrowLeft, Award,
  HelpCircle, Lightbulb, Loader2
} from 'lucide-react';
import type { Locale } from '@/lib/i18n';
import type { QuizQuestion } from '@/lib/quizData';
import { getQuestionText, getAnswerText, getExplanation } from '@/lib/quizData';

interface QuizComponentProps {
  questions: QuizQuestion[];
  locale: Locale;
  t: (key: any) => string;
  onExit: () => void;
  onComplete?: (correctCount: number, total: number) => void;
}

type QuizState = 'intro' | 'active' | 'result';

export default function QuizComponent({ questions, locale, t, onExit, onComplete }: QuizComponentProps) {
  const [state, setState] = useState<QuizState>('intro');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [answers, setAnswers] = useState<boolean[]>([]);

  const startQuiz = () => {
    setState('active');
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setCorrectCount(0);
    setAnswers([]);
  };

  const handleSelect = (index: number) => {
    if (showExplanation) return;
    setSelectedAnswer(index);
  };

  const handleSubmit = () => {
    if (selectedAnswer === null) return;
    const isCorrect = selectedAnswer === questions[currentIndex].correctIndex;
    setShowExplanation(true);
    if (isCorrect) {
      setCorrectCount((c) => c + 1);
    }
    setAnswers([...answers, isCorrect]);
  };

  const handleNext = () => {
    if (currentIndex + 1 >= questions.length) {
      setState('result');
      onComplete?.(correctCount, questions.length);
    } else {
      setCurrentIndex((i) => i + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    }
  };

  // === Intro screen ===
  if (state === 'intro') {
    return (
      <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-8 border border-blue-100 text-center">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/20">
          <HelpCircle className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-bold text-gray-900 mb-2">{t('practiceQuiz')}</h3>
        <p className="text-gray-600 text-sm mb-2">{t('quizDesc')}</p>
        <p className="text-gray-500 text-sm mb-6">
          {questions.length} {t('quizQuestionsCount')}
        </p>
        <div className="flex gap-3 justify-center">
          <button
            onClick={onExit}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-white border border-gray-200 text-gray-700 font-medium text-sm hover:bg-gray-50 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            {t('quizBackToCourse')}
          </button>
          <button
            onClick={startQuiz}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.02] transition-all"
          >
            <HelpCircle className="w-5 h-5" />
            {t('startQuiz')}
          </button>
        </div>
      </div>
    );
  }

  // === Result screen ===
  if (state === 'result') {
    const percentage = Math.round((correctCount / questions.length) * 100);
    const passed = correctCount >= Math.ceil(questions.length * 0.8);
    return (
      <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-8 border border-blue-100 text-center">
        <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg ${
          passed ? 'bg-gradient-to-br from-green-500 to-emerald-400 shadow-green-500/30' : 'bg-gradient-to-br from-amber-500 to-orange-400 shadow-amber-500/30'
        }`}>
          <Award className="w-10 h-10 text-white" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-2">{t('quizResult')}</h3>
        <p className="text-gray-500 text-sm mb-6">{t('quizScore')}</p>

        <div className="inline-flex items-baseline gap-1 mb-2">
          <span className={`text-5xl font-bold ${passed ? 'text-green-500' : 'text-amber-500'}`}>
            {correctCount}
          </span>
          <span className="text-2xl font-bold text-gray-400">/ {questions.length}</span>
        </div>
        <p className="text-gray-600 text-sm mb-1">
          {percentage}% · {correctCount} {t('quizCorrectCount')}
        </p>
        <p className={`font-medium text-sm mb-6 ${passed ? 'text-green-600' : 'text-amber-600'}`}>
          {passed
            ? (locale === 'fr' ? 'Bien joué ! Vous maîtrisez bien ce sujet.' : 'Well done! You have a good grasp of this topic.')
            : (locale === 'fr' ? 'Continuez à pratiquer pour améliorer votre score.' : 'Keep practicing to improve your score.')}
        </p>

        <div className="flex gap-3 justify-center">
          <button
            onClick={onExit}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-white border border-gray-200 text-gray-700 font-medium text-sm hover:bg-gray-50 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            {t('quizBackToCourse')}
          </button>
          <button
            onClick={startQuiz}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.02] transition-all"
          >
            <RotateCcw className="w-5 h-5" />
            {t('quizRetry')}
          </button>
        </div>
      </div>
    );
  }

  // === Active quiz ===
  const question = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;
  const isCorrect = selectedAnswer === question.correctIndex;

  return (
    <div>
      {/* Header with progress */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={onExit}
          className="flex items-center gap-2 text-gray-500 hover:text-gray-800 text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          {t('quizBackToCourse')}
        </button>
        <span className="text-sm font-medium text-gray-500">
          {t('quizQuestion')} {currentIndex + 1} / {questions.length}
        </span>
      </div>

      <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden mb-6">
        <div
          className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Question */}
      <div className="bg-white rounded-2xl border-2 border-gray-100 p-6 sm:p-8">
        <div className="flex items-start gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center flex-shrink-0">
            <HelpCircle className="w-5 h-5 text-blue-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 leading-relaxed pt-1">
            {getQuestionText(question, locale)}
          </h3>
        </div>

        {/* Answers */}
        <div className="space-y-3 mb-6">
          {question.answers.map((_, idx) => {
            const isSelected = selectedAnswer === idx;
            const isAnswerCorrect = idx === question.correctIndex;
            const showResult = showExplanation;

            let styleClass = 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50/30';
            if (showResult) {
              if (isAnswerCorrect) {
                styleClass = 'border-green-400 bg-green-50';
              } else if (isSelected && !isAnswerCorrect) {
                styleClass = 'border-red-400 bg-red-50';
              } else {
                styleClass = 'border-gray-100 bg-gray-50 opacity-60';
              }
            } else if (isSelected) {
              styleClass = 'border-blue-400 bg-blue-50';
            }

            return (
              <button
                key={idx}
                onClick={() => handleSelect(idx)}
                disabled={showExplanation}
                className={`w-full flex items-center gap-3 p-4 rounded-xl border-2 transition-all text-left ${styleClass} ${showExplanation ? 'cursor-default' : 'cursor-pointer'}`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-semibold text-sm flex-shrink-0 ${
                  showResult
                    ? isAnswerCorrect
                      ? 'bg-green-500 text-white'
                      : isSelected
                        ? 'bg-red-500 text-white'
                        : 'bg-gray-200 text-gray-400'
                    : isSelected
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-500'
                }`}>
                  {showResult && isAnswerCorrect ? (
                    <Check className="w-4 h-4" />
                  ) : showResult && isSelected && !isAnswerCorrect ? (
                    <X className="w-4 h-4" />
                  ) : (
                    String.fromCharCode(65 + idx)
                  )}
                </div>
                <span className={`text-sm font-medium ${
                  showResult && isAnswerCorrect ? 'text-green-800' : showResult && isSelected && !isAnswerCorrect ? 'text-red-800' : 'text-gray-700'
                }`}>
                  {getAnswerText(question, idx, locale)}
                </span>
              </button>
            );
          })}
        </div>

        {/* Explanation */}
        {showExplanation && (
          <div className={`rounded-xl p-4 mb-6 border ${
            isCorrect ? 'bg-green-50 border-green-200' : 'bg-amber-50 border-amber-200'
          }`}>
            <div className="flex items-center gap-2 mb-2">
              {isCorrect ? (
                <><Check className="w-5 h-5 text-green-600" /><span className="font-semibold text-green-700 text-sm">{t('quizCorrect')}</span></>
              ) : (
                <><X className="w-5 h-5 text-red-500" /><span className="font-semibold text-red-600 text-sm">{t('quizWrong')}</span></>
              )}
            </div>
            <div className="flex items-start gap-2">
              <Lightbulb className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-700 leading-relaxed">
                <span className="font-medium">{t('quizExplanation')}: </span>
                {getExplanation(question, locale)}
              </p>
            </div>
          </div>
        )}

        {/* Action buttons */}
        <div className="flex justify-end">
          {!showExplanation ? (
            <button
              onClick={handleSubmit}
              disabled={selectedAnswer === null}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.02] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Check className="w-5 h-5" />
              {locale === 'fr' ? 'Valider ma réponse' : 'Submit answer'}
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold shadow-lg shadow-blue-500/30 hover:scale-[1.02] transition-all"
            >
              {currentIndex + 1 >= questions.length ? t('quizFinish') : t('quizNext')}
              <ChevronRight className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
