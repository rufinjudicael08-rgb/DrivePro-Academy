import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { Country } from './types';
import { countries, getCountry } from './countries';
import { t as translate, type TranslationKey, type Locale } from './i18n';

interface AppContextValue {
  country: Country;
  setCountryCode: (code: string) => void;
  locale: Locale;
  t: (key: TranslationKey) => string;
  countries: typeof countries;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [countryCode, setCountryCode] = useState<string>(() => {
    return localStorage.getItem('drivepro_country') || 'FR';
  });

  const country = getCountry(countryCode) || countries[0];
  const locale: Locale = country.locale;

  useEffect(() => {
    localStorage.setItem('drivepro_country', countryCode);
  }, [countryCode]);

  const t = useCallback(
    (key: TranslationKey) => translate(locale, key),
    [locale]
  );

  return (
    <AppContext.Provider value={{ country, setCountryCode, locale, t, countries }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
