export interface Country {
  code: string;
  name_fr: string;
  name_en: string;
  flag: string;
  currency: string;
  currencySymbol: string;
  locale: 'fr' | 'en';
  paymentMethods: PaymentMethod[];
  exchangeRate: number; // relative to base unit (25000 base)
}

export type PaymentMethod = 'card' | 'mobile_money' | 'paypal' | 'sepa' | 'bank_transfer';

export interface Registration {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  country_code: string;
  city: string;
  birth_date: string | null;
  locale: string;
  currency: string;
  payment_method: string | null;
  payment_status: 'pending' | 'paid';
  file_complete: boolean;
  admin_fee_base: number;
  queue_number: number | null;
  queue_position: number | null;
  queue_status: 'pending' | 'waiting' | 'in_course' | 'validated';
  code_exam_score: number;
  code_exam_passed: boolean;
  instructor_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Instructor {
  id: string;
  name: string;
  phone: string;
  whatsapp: string;
  city: string;
  country_code: string;
  rating: number;
  languages: string[];
}

export interface CodeCourse {
  id: string;
  title_fr: string;
  title_en: string;
  description_fr: string;
  description_en: string;
  duration_minutes: number;
  lesson_order: number;
  is_exam: boolean;
}

export interface SocialCampaign {
  id: string;
  platform: string;
  label: string;
  tracked_url: string;
  clicks: number;
  conversions: number;
  active: boolean;
  created_at: string;
}

export type View = 'home' | 'register' | 'candidate' | 'agent';
