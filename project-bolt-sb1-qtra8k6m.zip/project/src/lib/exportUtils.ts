import type { Registration } from './types';
import { getCountry } from './countries';

function escapeCSV(value: string): string {
  if (value.includes(',') || value.includes('"') || value.includes('\n')) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

export function registrationsToCSV(registrations: Registration[], locale: 'fr' | 'en'): string {
  const headers = locale === 'fr'
    ? ['Nom complet', 'Email', 'Téléphone', 'Ville', 'Pays', 'Date de naissance', 'Langue', 'Devise', 'Méthode de paiement', 'Statut paiement', 'Frais de base', 'Dossier complet', 'Numéro de file', 'Position file', 'Statut file', 'Score code', 'Code réussi', 'Date d\'inscription', 'Dernière mise à jour']
    : ['Full name', 'Email', 'Phone', 'City', 'Country', 'Birth date', 'Locale', 'Currency', 'Payment method', 'Payment status', 'Base fee', 'File complete', 'Queue number', 'Queue position', 'Queue status', 'Code score', 'Code passed', 'Registration date', 'Last updated'];

  const rows = registrations.map((reg) => {
    const country = getCountry(reg.country_code);
    const countryName = country ? (locale === 'fr' ? country.name_fr : country.name_en) : reg.country_code;
    return [
      reg.full_name,
      reg.email,
      reg.phone,
      reg.city,
      countryName,
      reg.birth_date || '',
      reg.locale,
      reg.currency,
      reg.payment_method || '',
      reg.payment_status,
      String(reg.admin_fee_base),
      reg.file_complete ? (locale === 'fr' ? 'Oui' : 'Yes') : (locale === 'fr' ? 'Non' : 'No'),
      reg.queue_number ? String(reg.queue_number) : '',
      reg.queue_position ? String(reg.queue_position) : '',
      reg.queue_status,
      String(reg.code_exam_score),
      reg.code_exam_passed ? (locale === 'fr' ? 'Oui' : 'Yes') : (locale === 'fr' ? 'Non' : 'No'),
      new Date(reg.created_at).toLocaleString(locale === 'fr' ? 'fr-FR' : 'en-US'),
      new Date(reg.updated_at).toLocaleString(locale === 'fr' ? 'fr-FR' : 'en-US'),
    ];
  });

  const allRows = [headers, ...rows];
  return allRows.map((row) => row.map(escapeCSV).join(',')).join('\n');
}

export function registrationsToExcelXML(registrations: Registration[], locale: 'fr' | 'en'): string {
  const headers = locale === 'fr'
    ? ['Nom complet', 'Email', 'Téléphone', 'Ville', 'Pays', 'Date de naissance', 'Langue', 'Devise', 'Méthode de paiement', 'Statut paiement', 'Frais de base', 'Dossier complet', 'Numéro de file', 'Position file', 'Statut file', 'Score code', 'Code réussi', 'Date d\'inscription', 'Dernière mise à jour']
    : ['Full name', 'Email', 'Phone', 'City', 'Country', 'Birth date', 'Locale', 'Currency', 'Payment method', 'Payment status', 'Base fee', 'File complete', 'Queue number', 'Queue position', 'Queue status', 'Code score', 'Code passed', 'Registration date', 'Last updated'];

  const escapeXML = (s: string) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  const headerRow = headers.map((h) => `<Cell><Data ss:Type="String">${escapeXML(h)}</Data></Cell>`).join('');
  const dataRows = registrations.map((reg) => {
    const country = getCountry(reg.country_code);
    const countryName = country ? (locale === 'fr' ? country.name_fr : country.name_en) : reg.country_code;
    const values = [
      reg.full_name,
      reg.email,
      reg.phone,
      reg.city,
      countryName,
      reg.birth_date || '',
      reg.locale,
      reg.currency,
      reg.payment_method || '',
      reg.payment_status,
      String(reg.admin_fee_base),
      reg.file_complete ? (locale === 'fr' ? 'Oui' : 'Yes') : (locale === 'fr' ? 'Non' : 'No'),
      reg.queue_number ? String(reg.queue_number) : '',
      reg.queue_position ? String(reg.queue_position) : '',
      reg.queue_status,
      String(reg.code_exam_score),
      reg.code_exam_passed ? (locale === 'fr' ? 'Oui' : 'Yes') : (locale === 'fr' ? 'Non' : 'No'),
      new Date(reg.created_at).toLocaleString(locale === 'fr' ? 'fr-FR' : 'en-US'),
      new Date(reg.updated_at).toLocaleString(locale === 'fr' ? 'fr-FR' : 'en-US'),
    ];
    return `<Row>${values.map((v) => `<Cell><Data ss:Type="String">${escapeXML(v)}</Data></Cell>`).join('')}</Row>`;
  }).join('');

  return `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <Worksheet ss:Name="DrivePro Registrations">
  <Table>
   <Row>${headerRow}</Row>
   ${dataRows}
  </Table>
 </Worksheet>
</Workbook>`;
}

export function downloadFile(content: string, filename: string, mimeType: string): void {
  const blob = new Blob(['\ufeff' + content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
