import type { Locale } from './i18n';

export interface QuizQuestion {
  id: string;
  course_order: number;
  question: { fr: string; en: string };
  answers: { fr: string; en: string }[];
  correctIndex: number;
  explanation: { fr: string; en: string };
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: 'q_sign_stop',
    course_order: 1,
    question: {
      fr: "Que devez-vous faire à l'approche d'un panneau STOP ?",
      en: 'What must you do when approaching a STOP sign?',
    },
    answers: [
      { fr: "Ralentir et continuer si la voie est libre", en: 'Slow down and proceed if the road is clear' },
      { fr: "Arrêter complètement le véhicule", en: 'Come to a complete stop' },
      { fr: "Klaxonner puis passer", en: 'Honk and then proceed' },
      { fr: "Céder le passage sans s'arrêter", en: 'Yield without stopping' },
    ],
    correctIndex: 1,
    explanation: {
      fr: "Le panneau STOP impose un arrêt complet du véhicule, même si la voie semble libre. Vous devez marquer l'arrêt avant la ligne d'arrêt.",
      en: 'The STOP sign requires a complete stop, even if the road appears clear. You must stop before the stop line.',
    },
  },
  {
    id: 'q_sign_priority',
    course_order: 1,
    question: {
      fr: 'Un panneau triangulaire avec un bord rouge signifie généralement :',
      en: 'A triangular sign with a red border generally means:',
    },
    answers: [
      { fr: 'Une interdiction', en: 'A prohibition' },
      { fr: 'Une obligation', en: 'A requirement' },
      { fr: 'Un danger ou un avertissement', en: 'A danger or warning' },
      { fr: 'Une indication', en: 'An indication' },
    ],
    correctIndex: 2,
    explanation: {
      fr: "Les panneaux triangulaires à bord rouge signalent un danger ou un avertissement. Ils alertent le conducteur d'un risque particulier sur la route.",
      en: 'Triangular signs with red borders warn of danger. They alert the driver to a specific risk on the road.',
    },
  },
  {
    id: 'q_sign_yield',
    course_order: 1,
    question: {
      fr: "À un carrefour sans panneau de priorité, qui est prioritaire ?",
      en: 'At an intersection with no priority sign, who has right of way?',
    },
    answers: [
      { fr: "Le véhicule qui arrive le plus vite", en: 'The vehicle arriving fastest' },
      { fr: "Le véhicule qui vient de droite", en: 'The vehicle coming from the right' },
      { fr: "Le véhicule qui vient de gauche", en: 'The vehicle coming from the left' },
      { fr: "Le plus gros véhicule", en: 'The largest vehicle' },
    ],
    correctIndex: 1,
    explanation: {
      fr: "En l'absence de signalisation, la priorité à droite s'applique. Le véhicule venant de votre droite a la priorité.",
      en: 'In the absence of signs, priority to the right applies. The vehicle coming from your right has right of way.',
    },
  },
  {
    id: 'q_priority_roundabout',
    course_order: 2,
    question: {
      fr: "Dans un rond-point sans signalisation, qui est prioritaire ?",
      en: 'In an unmarked roundabout, who has right of way?',
    },
    answers: [
      { fr: "Les véhicules déjà engagés dans le rond-point", en: 'Vehicles already in the roundabout' },
      { fr: "Les véhicules qui veulent entrer", en: 'Vehicles wanting to enter' },
      { fr: "Personne n'a la priorité", en: 'No one has priority' },
      { fr: "Le véhicule le plus proche de la sortie", en: 'The vehicle closest to the exit' },
    ],
    correctIndex: 1,
    explanation: {
      fr: "Dans un rond-point sans signalisation spécifique, la priorité à droite s'applique : les véhicules entrants ont priorité. La plupart des rond-points modernes ont cependant un panneau « cédez le passage ».",
      en: 'In an unmarked roundabout, priority to the right applies: entering vehicles have right of way. Most modern roundabouts however have a "yield" sign.',
    },
  },
  {
    id: 'q_priority_emergency',
    course_order: 2,
    question: {
      fr: "Un véhicule d'urgence (police, pompier, ambulance) approche avec gyrophare. Que faites-vous ?",
      en: 'An emergency vehicle (police, fire, ambulance) approaches with lights on. What do you do?',
    },
    answers: [
      { fr: "Accélérer pour lui laisser le passage", en: 'Speed up to let it pass' },
      { fr: "Vous arrêtez sur place immédiatement", en: 'Stop immediately where you are' },
      { fr: "Ralentir et vous ranger sur le côté pour le laisser passer", en: 'Slow down and pull to the side to let it pass' },
      { fr: "Continuer normalement", en: 'Continue normally' },
    ],
    correctIndex: 2,
    explanation: {
      fr: "Face à un véhicule d'urgence, vous devez ralentir et vous ranger sur le côté pour faciliter son passage, sans créer de situation dangereuse.",
      en: 'When an emergency vehicle approaches, slow down and pull to the side to let it pass, without creating a dangerous situation.',
    },
  },
  {
    id: 'q_speed_urban',
    course_order: 3,
    question: {
      fr: "Quelle est la vitesse maximale autorisée en agglomération par défaut ?",
      en: 'What is the default maximum speed in built-up areas?',
    },
    answers: [
      { fr: '30 km/h', en: '30 km/h' },
      { fr: '50 km/h', en: '50 km/h' },
      { fr: '70 km/h', en: '70 km/h' },
      { fr: '80 km/h', en: '80 km/h' },
    ],
    correctIndex: 1,
    explanation: {
      fr: "En agglomération, la vitesse maximale par défaut est de 50 km/h, sauf indication contraire (zones 30, zones 70, etc.).",
      en: 'In built-up areas, the default maximum speed is 50 km/h, unless otherwise indicated (30 zones, 70 zones, etc.).',
    },
  },
  {
    id: 'q_speed_highway',
    course_order: 3,
    question: {
      fr: "Quelle est la vitesse maximale autorisée sur autoroute par défaut ?",
      en: 'What is the default maximum speed on highways?',
    },
    answers: [
      { fr: '110 km/h', en: '110 km/h' },
      { fr: '120 km/h', en: '120 km/h' },
      { fr: '130 km/h', en: '130 km/h' },
      { fr: '140 km/h', en: '140 km/h' },
    ],
    correctIndex: 2,
    explanation: {
      fr: "Sur autoroute, la vitesse maximale par défaut est de 130 km/h. En cas de pluie ou de mauvaises conditions, elle est réduite à 110 km/h.",
      en: 'On highways, the default maximum speed is 130 km/h. In rain or poor conditions, it is reduced to 110 km/h.',
    },
  },
  {
    id: 'q_safety_distance',
    course_order: 3,
    question: {
      fr: "À 90 km/h, quelle est la distance de sécurité minimale recommandée ?",
      en: 'At 90 km/h, what is the minimum recommended safety distance?',
    },
    answers: [
      { fr: "Au moins 20 mètres", en: 'At least 20 meters' },
      { fr: "Au moins 45 mètres", en: 'At least 45 meters' },
      { fr: "Au moins 90 mètres", en: 'At least 90 meters' },
      { fr: "Au moins 10 mètres", en: 'At least 10 meters' },
    ],
    correctIndex: 2,
    explanation: {
      fr: "La distance de sécurité correspond à environ 1 seconde de trajet. À 90 km/h, cela représente environ 90 mètres. Une astuce : multiplier le chiffre des dizaines par 3.",
      en: 'The safety distance corresponds to about 1 second of travel. At 90 km/h, that is approximately 90 meters. A tip: multiply the tens digit by 3.',
    },
  },
  {
    id: 'q_alcohol_limit',
    course_order: 4,
    question: {
      fr: "Quel est le taux d'alcoolémie maximal autorisé pour un conducteur expérimenté ?",
      en: 'What is the maximum blood alcohol level for an experienced driver?',
    },
    answers: [
      { fr: '0,2 g/l', en: '0.2 g/l' },
      { fr: '0,5 g/l', en: '0.5 g/l' },
      { fr: '0,8 g/l', en: '0.8 g/l' },
      { fr: '1,0 g/l', en: '1.0 g/l' },
    ],
    correctIndex: 1,
    explanation: {
      fr: "Le taux d'alcoolémie maximal est de 0,5 g/l de sang pour un conducteur expérimenté. Pour les jeunes conducteurs (permis probatoire), il est de 0,2 g/l.",
      en: 'The maximum blood alcohol level is 0.5 g/l for an experienced driver. For new drivers (probationary license), it is 0.2 g/l.',
    },
  },
  {
    id: 'q_alcohol_effect',
    course_order: 4,
    question: {
      fr: "L'alcool au volant a quel effet principal sur la conduite ?",
      en: 'What is the main effect of alcohol on driving?',
    },
    answers: [
      { fr: "Améliore les réflexes", en: 'Improves reflexes' },
      { fr: "Augmente le champ visuel", en: 'Increases visual field' },
      { fr: "Réduit les réflexes et altère le jugement", en: 'Reduces reflexes and impairs judgment' },
      { fr: "Aucun effet sur la conduite", en: 'No effect on driving' },
    ],
    correctIndex: 2,
    explanation: {
      fr: "L'alcool réduit les réflexes, altère le jugement, réduit le champ visuel (vision tubulaire) et augmente la prise de risque. C'est la première cause de mortalité sur les routes.",
      en: 'Alcohol reduces reflexes, impairs judgment, narrows the visual field (tunnel vision), and increases risk-taking. It is the leading cause of road fatalities.',
    },
  },
  {
    id: 'q_rain_distance',
    course_order: 5,
    question: {
      fr: "Sur route mouillée, la distance de freinage est multipliée par environ :",
      en: 'On a wet road, braking distance is multiplied by approximately:',
    },
    answers: [
      { fr: '1,5', en: '1.5' },
      { fr: '2', en: '2' },
      { fr: '3', en: '3' },
      { fr: '5', en: '5' },
    ],
    correctIndex: 1,
    explanation: {
      fr: "Sur route mouillée, la distance de freinage est environ doublée. Il faut donc augmenter la distance de sécurité et réduire la vitesse.",
      en: 'On a wet road, braking distance is roughly doubled. You should increase the safety distance and reduce speed.',
    },
  },
  {
    id: 'q_fog_lights',
    course_order: 5,
    question: {
      fr: "En cas de brouillard, quels feux devez-vous utiliser ?",
      en: 'In fog, which lights should you use?',
    },
 answers: [
      { fr: "Feux de croisement uniquement", en: 'Low beams only' },
      { fr: "Feux de brouillard avant et arrière", en: 'Front and rear fog lights' },
      { fr: "Feux de route (pleins phares)", en: 'High beams (full headlights)' },
      { fr: "Feux de position uniquement", en: 'Parking lights only' },
    ],
    correctIndex: 1,
    explanation: {
      fr: "En cas de brouillard, utilisez les feux de brouillard avant et arrière. Les feux de route sont contre-productifs car la lumière se réfléchit dans le brouillard.",
      en: 'In fog, use front and rear fog lights. High beams are counterproductive as the light reflects back in the fog.',
    },
  },
  {
    id: 'q_phone_driving',
    course_order: 5,
    question: {
      fr: "L'usage du téléphone au volant sans kit mains-libres est :",
      en: 'Using a phone while driving without a hands-free kit is:',
    },
    answers: [
      { fr: "Autorisé en ville", en: 'Allowed in the city' },
      { fr: "Interdit et sanctionné par une amende et un retrait de points", en: 'Prohibited and punished by a fine and point deduction' },
      { fr: "Autorisé si on roule lentement", en: 'Allowed if driving slowly' },
      { fr: "Autorisé sur autoroute", en: 'Allowed on highways' },
    ],
    correctIndex: 1,
    explanation: {
      fr: "Tenir un téléphone au volant est interdit et sévèrement sanctionné. Même avec un kit mains-libres, l'usage du téléphone reste dangereux car il distrait le conducteur.",
      en: 'Holding a phone while driving is prohibited and severely punished. Even with a hands-free kit, phone use remains dangerous as it distracts the driver.',
    },
  },
  {
    id: 'q_seatbelt',
    course_order: 5,
    question: {
      fr: "La ceinture de sécurité est obligatoire :",
      en: 'The seatbelt is mandatory:',
    },
    answers: [
      { fr: "Uniquement à l'avant", en: 'Only in the front' },
      { fr: "Uniquement sur autoroute", en: 'Only on highways' },
      { fr: "Pour tous les passagers, à l'avant comme à l'arrière", en: 'For all passengers, front and rear' },
      { fr: "Uniquement pour le conducteur", en: 'Only for the driver' },
    ],
    correctIndex: 2,
    explanation: {
      fr: "La ceinture de sécurité est obligatoire pour tous les passagers, à l'avant comme à l'arrière. Elle réduit le risque de décès de moitié en cas d'accident.",
      en: 'The seatbelt is mandatory for all passengers, front and rear. It halves the risk of death in case of an accident.',
    },
  },
  {
    id: 'q_exam_pass_threshold',
    course_order: 6,
    question: {
      fr: "Pour réussir l'examen du code, combien de fautes au maximum sont autorisées sur 40 questions ?",
      en: 'To pass the theory exam, how many errors are allowed maximum out of 40 questions?',
    },
    answers: [
      { fr: '3 fautes', en: '3 errors' },
      { fr: '5 fautes', en: '5 errors' },
      { fr: '10 fautes', en: '10 errors' },
      { fr: '0 faute', en: '0 errors' },
    ],
    correctIndex: 1,
    explanation: {
      fr: "Pour réussir l'examen du code de la route, vous devez faire au maximum 5 fautes sur 40 questions, soit un minimum de 35 bonnes réponses.",
      en: 'To pass the highway code exam, you must make at most 5 errors out of 40 questions, meaning at least 35 correct answers.',
    },
  },
];

export function getQuestionsForCourse(courseOrder: number): QuizQuestion[] {
  return quizQuestions.filter((q) => q.course_order === courseOrder);
}

export function getAllQuestions(): QuizQuestion[] {
  return quizQuestions;
}

export function getQuestionText(q: QuizQuestion, locale: Locale): string {
  return q.question[locale];
}

export function getAnswerText(q: QuizQuestion, index: number, locale: Locale): string {
  return q.answers[index][locale];
}

export function getExplanation(q: QuizQuestion, locale: Locale): string {
  return q.explanation[locale];
}
