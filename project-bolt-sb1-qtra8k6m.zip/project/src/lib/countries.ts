import type { Country, PaymentMethod } from './types';

// Base fee: 25000 (in EUR-equivalent base units)
// For XOF countries (West Africa), 25000 FCFA is used directly
// For EUR countries, 250 is the EUR equivalent (25000 / 100)
// exchangeRate: multiply base(25000) by this to get local amount, then format
// We define fee in EUR (250) and convert

const card: PaymentMethod = 'card';
const mobileMoney: PaymentMethod = 'mobile_money';
const paypal: PaymentMethod = 'paypal';
const sepa: PaymentMethod = 'sepa';
const bankTransfer: PaymentMethod = 'bank_transfer';

export const BASE_FEE_EUR = 250;

export const countries: Country[] = [
  // === Europe ===
  { code: 'FR', name_fr: 'France', name_en: 'France', flag: '🇫🇷', currency: 'EUR', currencySymbol: '€', locale: 'fr', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'BG', name_fr: 'Bulgarie', name_en: 'Bulgaria', flag: '🇧🇬', currency: 'BGN', currencySymbol: 'лв', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 1.955 },
  { code: 'PL', name_fr: 'Pologne', name_en: 'Poland', flag: '🇵🇱', currency: 'PLN', currencySymbol: 'zł', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 4.3 },
  { code: 'ES', name_fr: 'Espagne', name_en: 'Spain', flag: '🇪🇸', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'DK', name_fr: 'Danemark', name_en: 'Denmark', flag: '🇩🇰', currency: 'DKK', currencySymbol: 'kr', locale: 'en', paymentMethods: [card, mobileMoney, paypal, bankTransfer], exchangeRate: 7.44 },
  { code: 'DE', name_fr: 'Allemagne', name_en: 'Germany', flag: '🇩🇪', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'IT', name_fr: 'Italie', name_en: 'Italy', flag: '🇮🇹', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'BE', name_fr: 'Belgique', name_en: 'Belgium', flag: '🇧🇪', currency: 'EUR', currencySymbol: '€', locale: 'fr', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'PT', name_fr: 'Portugal', name_en: 'Portugal', flag: '🇵🇹', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'NL', name_fr: 'Pays-Bas', name_en: 'Netherlands', flag: '🇳🇱', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'GB', name_fr: 'Royaume-Uni', name_en: 'United Kingdom', flag: '🇬🇧', currency: 'GBP', currencySymbol: '£', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 0.79 },
  { code: 'IE', name_fr: 'Irlande', name_en: 'Ireland', flag: '🇮🇪', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'AT', name_fr: 'Autriche', name_en: 'Austria', flag: '🇦🇹', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'CH', name_fr: 'Suisse', name_en: 'Switzerland', flag: '🇨🇭', currency: 'CHF', currencySymbol: 'CHF', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 0.97 },
  { code: 'SE', name_fr: 'Suède', name_en: 'Sweden', flag: '🇸🇪', currency: 'SEK', currencySymbol: 'kr', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 11.2 },
  { code: 'NO', name_fr: 'Norvège', name_en: 'Norway', flag: '🇳🇴', currency: 'NOK', currencySymbol: 'kr', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 11.4 },
  { code: 'FI', name_fr: 'Finlande', name_en: 'Finland', flag: '🇫🇮', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'GR', name_fr: 'Grèce', name_en: 'Greece', flag: '🇬🇷', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'RO', name_fr: 'Roumanie', name_en: 'Romania', flag: '🇷🇴', currency: 'RON', currencySymbol: 'lei', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 4.97 },
  { code: 'CZ', name_fr: 'République Tchèque', name_en: 'Czech Republic', flag: '🇨🇿', currency: 'CZK', currencySymbol: 'Kč', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 25.2 },
  { code: 'HU', name_fr: 'Hongrie', name_en: 'Hungary', flag: '🇭🇺', currency: 'HUF', currencySymbol: 'Ft', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 389 },
  { code: 'HR', name_fr: 'Croatie', name_en: 'Croatia', flag: '🇭🇷', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'SK', name_fr: 'Slovaquie', name_en: 'Slovakia', flag: '🇸🇰', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'SI', name_fr: 'Slovénie', name_en: 'Slovenia', flag: '🇸🇮', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'LT', name_fr: 'Lituanie', name_en: 'Lithuania', flag: '🇱🇹', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'LV', name_fr: 'Lettonie', name_en: 'Latvia', flag: '🇱🇻', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'EE', name_fr: 'Estonie', name_en: 'Estonia', flag: '🇪🇪', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'LU', name_fr: 'Luxembourg', name_en: 'Luxembourg', flag: '🇱🇺', currency: 'EUR', currencySymbol: '€', locale: 'fr', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'MT', name_fr: 'Malte', name_en: 'Malta', flag: '🇲🇹', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },
  { code: 'CY', name_fr: 'Chypre', name_en: 'Cyprus', flag: '🇨🇾', currency: 'EUR', currencySymbol: '€', locale: 'en', paymentMethods: [card, sepa, paypal, bankTransfer], exchangeRate: 1 },

  // === West Africa (XOF zone) ===
  { code: 'BJ', name_fr: 'Bénin', name_en: 'Benin', flag: '🇧🇯', currency: 'XOF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'CI', name_fr: "Côte d'Ivoire", name_en: "Côte d'Ivoire", flag: '🇨🇮', currency: 'XOF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'SN', name_fr: 'Sénégal', name_en: 'Senegal', flag: '🇸🇳', currency: 'XOF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'TG', name_fr: 'Togo', name_en: 'Togo', flag: '🇹🇬', currency: 'XOF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'BF', name_fr: 'Burkina Faso', name_en: 'Burkina Faso', flag: '🇧🇫', currency: 'XOF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'ML', name_fr: 'Mali', name_en: 'Mali', flag: '🇲🇱', currency: 'XOF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'NE', name_fr: 'Niger', name_en: 'Niger', flag: '🇳🇪', currency: 'XOF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'GN', name_fr: 'Guinée', name_en: 'Guinea', flag: '🇬🇳', currency: 'GNF', currencySymbol: 'GNF', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 21000 },

  // === Central Africa ===
  { code: 'CM', name_fr: 'Cameroun', name_en: 'Cameroon', flag: '🇨🇲', currency: 'XAF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'GA', name_fr: 'Gabon', name_en: 'Gabon', flag: '🇬🇦', currency: 'XAF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'CG', name_fr: 'Congo', name_en: 'Congo', flag: '🇨🇬', currency: 'XAF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },
  { code: 'TD', name_fr: 'Tchad', name_en: 'Chad', flag: '🇹🇩', currency: 'XAF', currencySymbol: 'FCFA', locale: 'fr', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 655.957 },

  // === East Africa ===
  { code: 'KE', name_fr: 'Kenya', name_en: 'Kenya', flag: '🇰🇪', currency: 'KES', currencySymbol: 'KSh', locale: 'en', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 129 },
  { code: 'TZ', name_fr: 'Tanzanie', name_en: 'Tanzania', flag: '🇹🇿', currency: 'TZS', currencySymbol: 'TSh', locale: 'en', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 2520 },
  { code: 'UG', name_fr: 'Ouganda', name_en: 'Uganda', flag: '🇺🇬', currency: 'UGX', currencySymbol: 'USh', locale: 'en', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 3780 },
  { code: 'RW', name_fr: 'Rwanda', name_en: 'Rwanda', flag: '🇷🇼', currency: 'RWF', currencySymbol: 'RWF', locale: 'en', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 1300 },

  // === West Africa (non-XOF) ===
  { code: 'NG', name_fr: 'Nigéria', name_en: 'Nigeria', flag: '🇳🇬', currency: 'NGN', currencySymbol: '₦', locale: 'en', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 1600 },
  { code: 'GH', name_fr: 'Ghana', name_en: 'Ghana', flag: '🇬🇭', currency: 'GHS', currencySymbol: '₵', locale: 'en', paymentMethods: [mobileMoney, card, bankTransfer], exchangeRate: 15 },

  // === North America ===
  { code: 'US', name_fr: 'États-Unis', name_en: 'United States', flag: '🇺🇸', currency: 'USD', currencySymbol: '$', locale: 'en', paymentMethods: [card, paypal, bankTransfer], exchangeRate: 1.08 },
  { code: 'CA', name_fr: 'Canada', name_en: 'Canada', flag: '🇨🇦', currency: 'CAD', currencySymbol: 'C$', locale: 'en', paymentMethods: [card, paypal, bankTransfer], exchangeRate: 1.37 },

  // === South America ===
  { code: 'BR', name_fr: 'Brésil', name_en: 'Brazil', flag: '🇧🇷', currency: 'BRL', currencySymbol: 'R$', locale: 'en', paymentMethods: [card, paypal, bankTransfer], exchangeRate: 5.4 },
  { code: 'AR', name_fr: 'Argentine', name_en: 'Argentina', flag: '🇦🇷', currency: 'ARS', currencySymbol: '$', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 1020 },
  { code: 'CO', name_fr: 'Colombie', name_en: 'Colombia', flag: '🇨🇴', currency: 'COP', currencySymbol: '$', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 4200 },
  { code: 'MX', name_fr: 'Mexique', name_en: 'Mexico', flag: '🇲🇽', currency: 'MXN', currencySymbol: '$', locale: 'en', paymentMethods: [card, paypal, bankTransfer], exchangeRate: 19.5 },
  { code: 'CL', name_fr: 'Chili', name_en: 'Chile', flag: '🇨🇱', currency: 'CLP', currencySymbol: '$', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 950 },
  { code: 'PE', name_fr: 'Pérou', name_en: 'Peru', flag: '🇵🇪', currency: 'PEN', currencySymbol: 'S/', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 4.0 },

  // === Asia ===
  { code: 'CN', name_fr: 'Chine', name_en: 'China', flag: '🇨🇳', currency: 'CNY', currencySymbol: '¥', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 7.8 },
  { code: 'JP', name_fr: 'Japon', name_en: 'Japan', flag: '🇯🇵', currency: 'JPY', currencySymbol: '¥', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 161 },
  { code: 'KR', name_fr: 'Corée du Sud', name_en: 'South Korea', flag: '🇰🇷', currency: 'KRW', currencySymbol: '₩', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 1460 },
  { code: 'IN', name_fr: 'Inde', name_en: 'India', flag: '🇮🇳', currency: 'INR', currencySymbol: '₹', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 90 },
  { code: 'ID', name_fr: 'Indonésie', name_en: 'Indonesia', flag: '🇮🇩', currency: 'IDR', currencySymbol: 'Rp', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 17000 },
  { code: 'TH', name_fr: 'Thaïlande', name_en: 'Thailand', flag: '🇹🇭', currency: 'THB', currencySymbol: '฿', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 37 },
  { code: 'VN', name_fr: 'Vietnam', name_en: 'Vietnam', flag: '🇻🇳', currency: 'VND', currencySymbol: '₫', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 27000 },
  { code: 'PH', name_fr: 'Philippines', name_en: 'Philippines', flag: '🇵🇭', currency: 'PHP', currencySymbol: '₱', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 62 },
  { code: 'MY', name_fr: 'Malaisie', name_en: 'Malaysia', flag: '🇲🇾', currency: 'MYR', currencySymbol: 'RM', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 4.7 },
  { code: 'SG', name_fr: 'Singapour', name_en: 'Singapore', flag: '🇸🇬', currency: 'SGD', currencySymbol: 'S$', locale: 'en', paymentMethods: [card, bankTransfer, paypal], exchangeRate: 1.44 },
  { code: 'AE', name_fr: 'Émirats Arabes Unis', name_en: 'United Arab Emirates', flag: '🇦🇪', currency: 'AED', currencySymbol: 'د.إ', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 3.97 },
  { code: 'SA', name_fr: 'Arabie Saoudite', name_en: 'Saudi Arabia', flag: '🇸🇦', currency: 'SAR', currencySymbol: '﷼', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 4.06 },
  { code: 'TR', name_fr: 'Turquie', name_en: 'Turkey', flag: '🇹🇷', currency: 'TRY', currencySymbol: '₺', locale: 'en', paymentMethods: [card, bankTransfer], exchangeRate: 34 },

  // === Oceania ===
  { code: 'AU', name_fr: 'Australie', name_en: 'Australia', flag: '🇦🇺', currency: 'AUD', currencySymbol: 'A$', locale: 'en', paymentMethods: [card, paypal, bankTransfer], exchangeRate: 1.52 },
  { code: 'NZ', name_fr: 'Nouvelle-Zélande', name_en: 'New Zealand', flag: '🇳🇿', currency: 'NZD', currencySymbol: 'NZ$', locale: 'en', paymentMethods: [card, paypal, bankTransfer], exchangeRate: 1.67 },

  // === North Africa ===
  { code: 'MA', name_fr: 'Maroc', name_en: 'Morocco', flag: '🇲🇦', currency: 'MAD', currencySymbol: 'د.م.', locale: 'fr', paymentMethods: [card, mobileMoney, bankTransfer], exchangeRate: 10.8 },
  { code: 'DZ', name_fr: 'Algérie', name_en: 'Algeria', flag: '🇩🇿', currency: 'DZD', currencySymbol: 'د.ج', locale: 'fr', paymentMethods: [card, bankTransfer], exchangeRate: 134 },
  { code: 'TN', name_fr: 'Tunisie', name_en: 'Tunisia', flag: '🇹🇳', currency: 'TND', currencySymbol: 'د.ت', locale: 'fr', paymentMethods: [card, bankTransfer], exchangeRate: 3.4 },
  { code: 'EG', name_fr: 'Égypte', name_en: 'Egypt', flag: '🇪🇬', currency: 'EGP', currencySymbol: '£', locale: 'en', paymentMethods: [card, mobileMoney, bankTransfer], exchangeRate: 52 },
];

export function getCountry(code: string): Country | undefined {
  return countries.find((c) => c.code === code);
}

export function convertFee(country: Country): number {
  return Math.round(BASE_FEE_EUR * country.exchangeRate);
}

export function formatFee(country: Country): string {
  const amount = convertFee(country);
  const formatted = new Intl.NumberFormat(country.locale === 'fr' ? 'fr-FR' : 'en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
  return `${formatted} ${country.currencySymbol}`;
}

export const paymentMethodLabels: Record<PaymentMethod, { fr: string; en: string; icon: string }> = {
  card: { fr: 'Carte bancaire', en: 'Bank card', icon: 'credit-card' },
  mobile_money: { fr: 'Mobile Money', en: 'Mobile Money', icon: 'smartphone' },
  paypal: { fr: 'PayPal', en: 'PayPal', icon: 'wallet' },
  sepa: { fr: 'Virement SEPA', en: 'SEPA transfer', icon: 'building-2' },
  bank_transfer: { fr: 'Virement bancaire', en: 'Bank transfer', icon: 'landmark' },
};
