import { useState } from 'react';
import { AppProvider } from '@/lib/context';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Home from '@/components/Home';
import RegistrationFlow from '@/components/RegistrationFlow';
import CandidateSpace from '@/components/CandidateSpace';
import AgentSpace from '@/components/AgentSpace';
import type { View, Registration } from '@/lib/types';

function AppContent() {
  const [view, setView] = useState<View>('home');
  const [existingRegistration, setExistingRegistration] = useState<Registration | null>(null);

  const handleNavigate = (v: View) => {
    setView(v);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header currentView={view} onNavigate={handleNavigate} />
      <main className="flex-1">
        {view === 'home' && <Home onNavigate={handleNavigate} />}
        {view === 'register' && (
          <RegistrationFlow
            onNavigate={handleNavigate}
            existingRegistration={existingRegistration}
            onRegistrationChange={setExistingRegistration}
          />
        )}
        {view === 'candidate' && <CandidateSpace onNavigate={handleNavigate} />}
        {view === 'agent' && <AgentSpace onNavigate={handleNavigate} />}
      </main>
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
